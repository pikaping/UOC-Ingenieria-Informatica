package edu.uoc.epcsd.notification.services;

import edu.uoc.epcsd.notification.kafka.ProductMessage;
import edu.uoc.epcsd.notification.rest.dtos.GetUserResponse;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

@Log4j2
@Component
public class NotificationService {

    @Value("${userService.getUsersToAlert.url}")
    private String userServiceUrl;

    public void notifyProductAvailable(ProductMessage productMessage) {

        // TODO: Use RestTemplate with the above userServiceUrl to query the User microservice in order to get the users that have an alert for the specified product (the date specified in the parameter may be the actual date: LocalDate.now()).
        //  Then simulate the email notification for the alerted users by logging a line with INFO level for each user saying "Sending an email to user " + the user fullName
        try {
            RestTemplate restTemplate = new RestTemplate();

            String expandedUrl = UriComponentsBuilder.fromUriString(userServiceUrl)
                    .buildAndExpand(productMessage.getProductId(), LocalDate.now().toString())
                    .toUriString();

            ResponseEntity<GetUserResponse[]> response = restTemplate.getForEntity(expandedUrl, GetUserResponse[].class);

            if (response.getStatusCode().is2xxSuccessful() && response.getBody() != null) {
                List<GetUserResponse> usersToAlert = Arrays.asList(response.getBody());
                usersToAlert.forEach(user -> log.info("Se ha notificado por correo el usuario " + user.getFullName() + " que existe una unidad disponible del producto " + productMessage.getProductId() + " || Email: " + user.getEmail() ));
            } else {
                log.error("Error getting users to alert: " + response.getStatusCode());
            }
        } catch (Exception ex) {
            log.error("Error in notifyProductAvailable: ", ex);
        }

    }
}
