package edu.uoc.epcsd.productcatalog.domain;

public enum ItemStatus {

    OPERATIONAL,
    NON_OPERATIONAL;

}
