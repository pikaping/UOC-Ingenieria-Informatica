package edu.uoc.epcsd.productcatalog.integrationtest;

import edu.uoc.epcsd.productcatalog.domain.Category;
import edu.uoc.epcsd.productcatalog.domain.repository.CategoryRepository;
import edu.uoc.epcsd.productcatalog.infrastructure.repository.jpa.CategoryEntity;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;

import org.springframework.transaction.annotation.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;

import javax.persistence.EntityManager;

@Transactional
@SpringBootTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
class CatalogRepositoryIntegrationTest {
    @Autowired
    private EntityManager entityManager;
    @Autowired
    private CategoryRepository categoryRepository;
    @Test
    public void testFindCategoryById() {
        Category category = new Category();
        category.setId(1L);
        category.setName("Test Category");
        category.setDescription("Test description");
        CategoryEntity entity = CategoryEntity.fromDomain(category);

        entityManager.persist(entity);
        Category foundCategory = categoryRepository.findCategoryById(category.getId()).get();

        Assertions.assertNotNull(foundCategory);
        Assertions.assertEquals(category.getId(), foundCategory.getId());
    }
}