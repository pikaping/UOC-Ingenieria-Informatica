package edu.uoc.epcsd.productcatalog.unittest;

import edu.uoc.epcsd.productcatalog.domain.Category;
import edu.uoc.epcsd.productcatalog.domain.service.CategoryService;
import edu.uoc.epcsd.productcatalog.application.rest.CategoryRESTController;

import java.util.List;
import java.util.Arrays;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;

import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.mockito.Mockito.when;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;

import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;

@ExtendWith(MockitoExtension.class)
class CategoryControllerUnitTest {

    @Mock
    private CategoryService categoryService;

    private MockMvc mockMvc;

    @BeforeEach
    void setup() {
        Category category1 = new Category();
        category1.setId(1L);
        category1.setName("Test1");
        category1.setDescription("Desc1");
        Category category2 = new Category(1L);
        category2.setId(2L);
        category2.setName("Test2");
        category2.setDescription("Desc2");
        List<Category> categories = Arrays.asList(category1, category2);
        when(categoryService.findAllCategories()).thenReturn(categories);

        CategoryRESTController categoryRESTController = new CategoryRESTController(categoryService);
        mockMvc = MockMvcBuilders.standaloneSetup(categoryRESTController).build();
    }

    @Test
    void testGetAllCategories() throws Exception{
        mockMvc.perform(get("/categories").contentType(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$", hasSize(2)))
                .andExpect(jsonPath("$[0].name", is("Test1")))
                .andExpect(jsonPath("$[1].id", is(2)))
                .andExpect(jsonPath("$[0].description", is("Desc1")))
                .andExpect(jsonPath("$[1].parentId", is(1)));
    }
}
