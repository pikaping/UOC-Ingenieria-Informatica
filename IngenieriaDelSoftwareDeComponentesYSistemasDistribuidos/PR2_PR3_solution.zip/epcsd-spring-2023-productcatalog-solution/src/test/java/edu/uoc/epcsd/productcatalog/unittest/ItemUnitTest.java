package edu.uoc.epcsd.productcatalog.unittest;

import edu.uoc.epcsd.productcatalog.domain.Item;
import edu.uoc.epcsd.productcatalog.domain.ItemStatus;

import org.junit.jupiter.api.Test;
import static org.assertj.core.api.Assertions.assertThat;

class ItemUnitTest {
    @Test
    void whenItemIsSetToNonOperational_itsStatusIsNonOperational() {
        Item item = new Item();
        item.setStatus(ItemStatus.NON_OPERATIONAL);
        assertThat(item.getStatus()).isEqualTo(ItemStatus.NON_OPERATIONAL);
    }
}
