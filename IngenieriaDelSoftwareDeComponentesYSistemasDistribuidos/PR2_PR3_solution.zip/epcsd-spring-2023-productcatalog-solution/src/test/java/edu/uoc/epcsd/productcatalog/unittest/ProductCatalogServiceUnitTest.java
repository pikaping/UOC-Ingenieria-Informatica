package edu.uoc.epcsd.productcatalog.unittest;

import edu.uoc.epcsd.productcatalog.domain.Product;
import edu.uoc.epcsd.productcatalog.domain.service.ProductService;

import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Optional;


@ExtendWith(MockitoExtension.class)
public class ProductCatalogServiceUnitTest {

    @Mock
    private ProductService productService;

    @Test
    void whenValidId_thenProductShouldBeFound() {
        Long id = 1L;
        Product expectedProduct = new Product();
        expectedProduct.setId(id);
        when(productService.findProductById(id)).thenReturn(Optional.of(expectedProduct));
        Optional<Product> actualProduct = productService.findProductById(id);
        assertTrue(actualProduct.isPresent(), "Expected product to be present");
        assertEquals(expectedProduct, actualProduct.get());
    }

    @Test
    void whenInvalidId_thenProductNotFoundException() {
        Long id = 2L;
        when(productService.findProductById(id)).thenReturn(Optional.empty());
        assertFalse(productService.findProductById(id).isPresent(), "Expected product to be not present");
    }
}
