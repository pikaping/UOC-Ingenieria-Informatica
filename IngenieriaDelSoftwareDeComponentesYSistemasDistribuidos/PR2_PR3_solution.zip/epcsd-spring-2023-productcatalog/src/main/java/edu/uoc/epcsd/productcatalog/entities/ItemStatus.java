package edu.uoc.epcsd.productcatalog.entities;

public enum ItemStatus {

    OPERATIONAL,
    NON_OPERATIONAL;

}
