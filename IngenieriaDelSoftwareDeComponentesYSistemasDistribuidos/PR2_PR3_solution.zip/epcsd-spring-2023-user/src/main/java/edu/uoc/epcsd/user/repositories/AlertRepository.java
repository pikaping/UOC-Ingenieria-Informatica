package edu.uoc.epcsd.user.repositories;

import edu.uoc.epcsd.user.entities.Alert;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.time.LocalDate;
import java.util.List;

public interface AlertRepository extends JpaRepository<Alert, Long> {

    @Query("select a from Alert a where a.productId = ?1 and a.from <= ?2 and a.to >= ?2")
    List<Alert> findAlertsByProductIdAndInterval(Long productId, LocalDate availableOnDate);

    @Query("select a from Alert a where a.productId = ?1 and a.from <= ?2 and a.to >= ?2")
    List<Alert> findAlertsByProductIdAndDate(Long productId, LocalDate date);


    @Query("select a from Alert a where a.user.id = ?1 and ((a.from <= ?2 and a.to >= ?2) or (a.from <= ?3 and a.to >= ?3) or (a.from >= ?2 and a.to <= ?3))")
    List<Alert> findAlertsByUserIdAndDateInterval(Long userId, LocalDate startDate, LocalDate endDate);

}
