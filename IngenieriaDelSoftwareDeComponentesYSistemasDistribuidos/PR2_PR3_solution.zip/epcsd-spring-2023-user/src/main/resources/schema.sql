INSERT INTO "user" (full_Name, email, password, phone_number)
VALUES ('Juan Palomo', 'juanpa@gmail.com', '12345', 654233521)
     , ('Francisco Pérez', 'fperez@gmail.com', 'blabla', 612446666)
     , ('José Manuel García', 'jmgarcia@terra.es', 'manue', 608721126)
     , ('Carles Vidal', 'vidal_c@gmail.com', 'admin', 654233521)
     , ('Nil Carbonell', 'neil@gmail.com', 'root', 654233521)
     ;
