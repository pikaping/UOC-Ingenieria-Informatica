#ifndef __UOCONG_API__H
#define __UOCONG_API__H
#include <stdbool.h>
#include "error.h"
#include "csv.h"

#include "person.h"
#include "project.h"
#include "campaign.h"

// Type that stores all the application data
typedef struct _ApiData {
    ////////////////////////////////
    // PR1 EX2a
    // Staff
    tStaff staff;
    // Projects
    tProjectList projects;
    // Vaccine lots
    tCampaignData campaignData;
    //tVaccineLotData vaccineLots;
    ////////////////////////////////
    
} tApiData;

// Get the API version information
const char* api_version();

// Load data from a CSV file. If reset is true, remove previous data
tApiError api_loadData(tApiData* data, const char* filename, bool reset);

// Add a new entry
tApiError api_addDataEntry(tApiData* data, tCSVEntry entry);

// Free all used memory
tApiError api_freeData(tApiData* data);

// Initialize the data structure
tApiError api_initData(tApiData* data);

// Add a new campaign
tApiError api_addCampaign(tApiData* data, tCSVEntry entry);

// Get the number of people registered on the application
int api_staffCount(tApiData data);

// Get the number of projects registered on the application
int api_projectCount(tApiData data);

// Get the number of campaigns registered on the application
int api_campaignCount(tApiData data);

// Get project data
tApiError api_getProject(tApiData data, const char *code, tCSVEntry *entry);

// Get Campaign data
tApiError api_getCampaign(tApiData data, const char* code, const char* city, tDate date, tCSVEntry *entry);

// Get registered projects
tApiError api_getProjects(tApiData data, tCSVData *projects);

// Get the registered campaings
tApiError api_getCampaigns(tApiData data, tCSVData *campaigns);


#endif // __UOCONG_API__H