#ifndef __TEST_DATA__H
#define __TEST_DATA__H

/*
 "PERSON;87654321K;John;Smith;john.smith@example.com;My street, 25;Barcelona;30/12/1980\n" \
 "PERSON;98765432J;Jane;Doe;jane.doe@example.com;Her street, 5;Barcelona;12/01/1995\n" \
 "PERSON;98232222A;Krunal;Doe;krunal.miracle@example.com;His street, 5;Badalona;21/05/2000\n" \
 "PERSON;87621123B;Pep;Botera;pepe.botera@example.com;His street, 20;Barcelona;12/01/1972\n"
*/

// Define test data for PR1
const char* test_data_pr1_str = 
							"CAMPAIGN;M001;MSF;Barcelona;01/01/2023;12500.00;15\n" \
                            "CAMPAIGN;C002;CRE;Tortosa;15/02/2023;50000.00;20\n" \
                            "CAMPAIGN;A100;ACN;Girona;01/01/2023;65000.00;50\n" \
                            "CAMPAIGN;C100;CRE;Olot;20/01/2023;25000.00;25\n" \
                            "CAMPAIGN;M100;MSF;Berga;02/01/2023;27000.00;15\n";                            

// Define test data for PR2
const char* test_data_pr2_str = "";

// Define test data for PR3
const char* test_data_pr3_str = ""; 

                                                        
#endif // TEST_DATA__H

/*
typedef struct _tCampaign {
    tProject* project;
    tDate date;
    char *city;
    float cost; 
    int numPeople;
} tCampaign;

*/