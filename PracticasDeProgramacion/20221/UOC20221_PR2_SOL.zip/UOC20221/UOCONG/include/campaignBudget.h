#ifndef __CAMPAIGN_BUDGET_DATA__H
#define __CAMPAIGN_BUDGET_DATA__H

#include "campaign.h"
#include "project.h"
#include "date.h"
#include "person.h"


typedef struct _tCampaignNode {
    tCampaign* elem;
    struct _tCampaignNode* next;
} tCampaignNode;


typedef struct _tCampaignDaily {
    tDate date;
    tCampaignNode* first;
    struct _tCampaignDaily* next;
    int count;
} tCampaignDaily;

// List of campaignDaily
typedef struct _tCampaignBudgetDataList {    
    tCampaignDaily* first;
    tCampaignDaily* last;
    int count;
} tCampaignBudgetDataList;



// Initialize a budget data list
void campaignBudgetDataList_init(tCampaignBudgetDataList* list);

// add 
int campaignBudgetDataList_add(tCampaignBudgetDataList* list, tDate date, tCampaign* campaign);

tCampaignDaily* campaignBudgetDataList_getCampaignDaily(tCampaignBudgetDataList* list, tDate date);
//
float campaignBudgetDataList_getDailyCost(tCampaignBudgetDataList* list, tDate date);

int campaignBudgetDataList_campaignNodeCounts(tCampaignBudgetDataList* list, tDate date);

int campaignBudgetDataList_campaignDailyCounts(tCampaignBudgetDataList* list);

bool campaignBudgetDataList_existsCampaign(tCampaignBudgetDataList* list, tDate date, tCampaign* campaign);

// Release a list of campaignBudgetDataList
void campaignBudgetDataList_free(tCampaignBudgetDataList* list);

tCampaignDaily* campaignBudgetDataList_find(tCampaignBudgetDataList* list, tDate date);



// Aux

bool campaignBudgetDataList_date_isBefore(tCampaignBudgetDataList* list, tDate date );
bool campaignBudgetDataList_date_isInRange(tCampaignBudgetDataList* list, tDate date);


#endif // __CAMPAIGN_BUDGET_DATA__H