#ifndef __PERSON_H__
#define __PERSON_H__
#include "csv.h"
#include "date.h"

///////////////////////////
// Maximum number of projects
#define MAX_PROJECTS 100

typedef struct _tPerson {
    char* document;
    char* name;
    char* surname;
    char* email;
    char* address;
    char* city;
    tDate birthday;
} tPerson;

typedef struct _tStaff {
    tPerson* elems;
    int count;
} tStaff;


// Initialize the staff data
void staff_init(tStaff* data);

// Initialize a person structure
void person_init(tPerson* data);

// Remove the data from a person
void person_free(tPerson* data);

// Remove the data from all people
void staff_free(tStaff* data);

// Parse input from CSVEntry
void person_parse(tPerson* data, tCSVEntry entry);

// Add a new person
void staff_add(tStaff* data, tPerson person);

// Remove a person
void staff_del(tStaff* data, const char *document);

// Return the position of a person with provided document. -1 if it does not exist
int staff_find(tStaff data, const char* document);

// Print the person data
void staff_print(tStaff data);

// Copy the data from the source to destination
void person_cpy(tPerson* destination, tPerson source);

// Return population lenght
int staff_len(tStaff data);

#endif
