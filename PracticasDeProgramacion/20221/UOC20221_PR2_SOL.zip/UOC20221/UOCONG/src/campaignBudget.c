#include <assert.h>
#include <stdlib.h>
#include <string.h>
#include "campaignDaily.h"
#include "campaignBudget.h"
#include "campaign.h"
#include "error.h"

// Initialize a Campaign budget data list
void campaignBudgetDataList_init(tCampaignBudgetDataList* list){
    // PR2 Ex 1a
    assert(list != NULL);
    
    list->count = 0;
    list->first = NULL;
    list->last = NULL;
    /////////////////
}

int campaignBudgetDataList_add(tCampaignBudgetDataList* list, tDate date, tCampaign* campaign) {
    tCampaignDaily* pDaily;
    // PR2 Ex 1b
    assert(list != NULL);
    
    // If the list is empty, just add a new element
    if (list->count == 0) {
        // Create the new element
        list->first = (tCampaignDaily*) malloc(sizeof(tCampaignDaily));
        assert(list->first != NULL);
        list->last = list->first;
        list->count = 1;        
        // Initialize the new campaignDaily elements
        campaignDaily_init(list->first, date);
		
		// Initialize the new campaignNode 
		campaignNode_init(list->first, campaign);

		
        // Update the project budget
		campaign->project->budget-=campaign->cost;
    } else {
        if (campaignBudgetDataList_existsCampaign(list, date, campaign)) {
            return E_DUPLICATED;
        }
        else {
            if (campaignBudgetDataList_date_isBefore(list, date)){
                // Date is before other dates. Add missing elements at left
                campaignDailyList_expandLeft(list, date);
                // Set start position for update the first element
                pDaily = list->first;            
            }
            else if (campaignBudgetDataList_date_isInRange(list, date)) {
                // Date is in the range of dates we already have. We will start updating on provided date.
                pDaily = campaignBudgetDataList_find(list, date);
            }
            else {
              // Date is after the end date. We will extend current campaignDaily up 
              // to the date and then update recursivelly
              campaignDailyList_expandRight(list, date);
              // Set start position for update the last element
              pDaily = list->last;
               
            }
            assert(pDaily != NULL);
            campaignNode_add(pDaily, campaign);
            // Update the project budget
			campaign->project->budget-=campaign->cost;
        }
	}
	
	// Once updated, remove empty elements
    campaignDailyList_purge(list);

	return E_SUCCESS;
}

float campaignBudgetDataList_getDailyCost(tCampaignBudgetDataList* list, tDate date) {
    tCampaignDaily* campaignDaily;
    float dailyCost=0.0;
    
    campaignDaily = campaignBudgetDataList_getCampaignDaily(list, date);
    if (campaignDaily != NULL) {
        dailyCost = campaignDaily_getDailyCost(campaignDaily);
    }
    
    return dailyCost;
    
    return 0.0;
}

int campaignBudgetDataList_campaignNodeCounts(tCampaignBudgetDataList* list, tDate date){
    tCampaignDaily* pCampaignDaily;
    pCampaignDaily = campaignBudgetDataList_getCampaignDaily(list, date);
	return (pCampaignDaily != NULL?pCampaignDaily->count:0);
}

int campaignBudgetDataList_campaignDailyCounts(tCampaignBudgetDataList* list) {
     return list->count;
}


tCampaignDaily* campaignBudgetDataList_getCampaignDaily(tCampaignBudgetDataList* list, tDate date) {
    tCampaignDaily* pCampaignDaily;
	tCampaignDaily* ret;
    bool found = false;

    pCampaignDaily = list->first;

    while (!found && pCampaignDaily != NULL) {
        found = date_cmp(date, pCampaignDaily->date)==0;
        if (found) {
            ret = pCampaignDaily;
        }

        pCampaignDaily = pCampaignDaily->next;
    }

    return (found?ret:NULL);
}

bool campaignBudgetDataList_existsCampaign(tCampaignBudgetDataList* list, tDate date, tCampaign* campaign){
	tCampaignDaily* pDaily;
	tCampaignNode* campaignNode=NULL;
	
	pDaily = campaignBudgetDataList_find(list, date);
	
	if (pDaily!= NULL) {
        campaignNode = campaignNode_findCampaign(pDaily->first, campaign);
    }

	return (campaignNode!=NULL);
}

// Find the campaign Daily for a given date
tCampaignDaily* campaignBudgetDataList_find(tCampaignBudgetDataList* list, tDate date) {
    tCampaignDaily *pNode;
    tCampaignDaily *pDate;
    
    assert(list != NULL);
    
    // Find the node
    pDate = NULL;
    if (list->count > 0 && date_cmp(list->first->date, date) <= 0 && date_cmp(list->last->date, date) >= 0) {
        pNode = list->first;
        while(pNode != NULL && pDate == NULL) {
            if(date_cmp(pNode->date, date) == 0) {
                // Point current node
                pDate = pNode;
            }
            pNode = pNode->next;
        }
    }
    
    return pDate;    
}




// Release the campaignBudgetDataList
void campaignBudgetDataList_free(tCampaignBudgetDataList* list) {
    // 
    tCampaignDaily* pNode;
    
    assert(list != NULL);
    
    pNode = list->first;
    
    while (pNode != NULL) {
        list->first = pNode->next;
        campaignDaily_free(pNode);
        free(pNode);
        list->count--;
        
        pNode = list->first;
    }
    list->first = NULL;
    list->last = NULL;
    /////////////////
}

/////////////////////////////////////////
///// AUX Methods: Top-down design //////
/////////////////////////////////////////

// Remove entries with no data on the start and end of the list
void campaignDailyList_purge(tCampaignBudgetDataList* list) {
    tCampaignDaily *pNode;
    tCampaignDaily *pAux;
    bool start;
    
    assert(list != NULL);
    
    pNode = list->first;
    pAux = NULL;
    
    start = true;
    while (pNode != NULL) {
        // Remove empty nodes
        campaignDaily_purge(pNode);
        //dailyStock_purge(pNode);
        
        // If node has no data...
        if (pNode->count == 0) {            
            if (start) {
                // If we are on the first element, remove the element
                list->first = pNode->next;
                campaignDaily_free(pNode);
                free(pNode);
                list->count--;
                pNode = list->first;
            } else {
                // On other nodes just move to the next node
                pNode = pNode->next;
                start = false;
            }
            
        } else {
            // Store the last node with data
            pAux = pNode;
            pNode = pNode->next;
            start = false;
        }                
    }
    
    // Remove empty nodes at the end
    if (pAux != NULL) {
        pNode = pAux->next;
        while(pNode != NULL) {
            pAux->next = pNode->next;
            campaignDaily_free(pNode);
            free(pNode);
            list->count--;
            pNode = pAux->next;
        }
        list->last = pAux;
    }
}


// Extend the list adding empty day cells on left
void campaignDailyList_expandLeft(tCampaignBudgetDataList* list, tDate date) {
    tDate today;
    tCampaignDaily* pAux;
    
    // Select the day previous to the first one
    today = list->first->date;
    date_addDay(&today, -1);
    
    // Iterate up to the top left date
    while (date_cmp(today, date) >= 0) {
        // Store current element
        pAux = list->first;
        // Add an element at first position
        list->first = (tCampaignDaily*) malloc(sizeof(tCampaignDaily));
        assert(list->first != NULL);        
        list->count++;        
        // Initialize the new element
		campaignDaily_init(list->first, today);        
        // Set old first element as next element
        list->first->next = pAux;
        // Decrement the date
        date_addDay(&today, -1);
    }
}

// Extend the list to the right with the data of the last position
void campaignDailyList_expandRight(tCampaignBudgetDataList* list, tDate date) {
    tDate today;
        
    // Select as today the day after the last day
    today = list->last->date;
    date_addDay(&today, 1);
    // Iterate for all dates up to the top right date
    while (date_cmp(today, date) <= 0) {        
        // Add an element at first position
        list->last->next = (tCampaignDaily*) malloc(sizeof(tCampaignDaily));
        assert(list->last->next != NULL);        
        list->count++;                
        // Initialize the new element
        campaignDaily_init(list->last->next, today);        
        // Copy the contents from old last element
        //campaignDaily_copy(list->last, list->last->next);        
        // Set the new last element
        list->last = list->last->next;
        // Increment the date
        date_addDay(&today, 1);
    }
}

bool campaignBudgetDataList_date_isBefore(tCampaignBudgetDataList* list, tDate date ) {
   return  (date_cmp(list->first->date, date) > 0);
}

bool campaignBudgetDataList_date_isInRange(tCampaignBudgetDataList* list, tDate date) {
    return (date_cmp(date, list->last->date) <= 0);
}
