#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include <stdio.h>
#include "project.h"
#include "campaign.h"
#include "error.h"

// Initialize project structure
void project_init(tProject* project, const char* code, const char* ongCode, float budget){
	int len;
    assert(project != NULL);
    assert(code != NULL);
    assert(ongCode != NULL);
    
    // Allocate memory for the code
	len = strlen(code)+1;
    project->code = (char*) malloc(len);
	memset(project->code, 0, len);

    assert(project->code != NULL);

    // Allocate memory for the ongCode
	len = strlen(ongCode)+1;
    project->ongCode = (char*) malloc(len);
	memset(project->ongCode, 0, len);
    assert(project->ongCode != NULL);

    // Set the data
    strcpy(project->code, code);
    strcpy(project->ongCode, ongCode);

    project->budget = budget;
    
}


// Release project data
void project_free(tProject* project) {
    assert(project != NULL);
    
    // Release used memory
    if (project->code != NULL) {
        free(project->code);
        project->code = NULL;
    }
    if (project->ongCode != NULL) {
        free(project->ongCode);
        project->ongCode = NULL;
    }
}


// Copy the data of a project from the source to destination
void project_cpy(tProject* destination, tProject source) {
    assert(destination != NULL);
    
    // Set the data
    project_init(destination, source.code, source.ongCode, source.budget);
}


// Parse project data from CSV Campaign entry
void project_parse(tProject* project, tCSVEntry entry) {
	char* code;
	char* ongCode;
    float budget;

    // Check input data
    assert(project != NULL);
    assert(csv_numFields(entry) == 7 || csv_numFields(entry) == 8);

    // Get project data
	// code
	code = entry_getString(&entry, 4); 
	
	// ongCode
	ongCode = entry_getString(&entry, 1);

	// budget
    budget = 0.0;
    if (csv_numFields(entry) == 8) {
        budget = csv_getAsReal(entry, 7);        
    }

	project_init(project, code, ongCode, budget);
	
	free(code);
	free(ongCode);
}


// Initialize the project's list
void projectList_init(tProjectList* list) {
    assert(list != NULL);
    
    list->first = NULL;
    list->count = 0;
}

// Remove all elements
void projectList_free(tProjectList* list) {
    tProjectNode *pNode = NULL;
    tProjectNode *pAux = NULL;
    
    assert(list != NULL);
    
    pNode = list->first;
    while(pNode != NULL) {
        // Store the position of the current node
        pAux = pNode;
        
        // Move to the next node in the list
        pNode = pNode->next;
        
        // Remove previous node
        project_free(&(pAux->project));
        free(pAux);
    }
    
    // Initialize to an empty list
    projectList_init(list);
}

// Get the number of projects
int projectList_len(tProjectList list) {
    return list.count;
}

// Find a project in the list of projects
tProject* projectList_find(tProjectList list, const char* code) {
    tProjectNode *pNode = NULL;
    tProjectNode *pProjectNode = NULL;
        
    // Point the first element
    pNode = list.first;
    
    while(pNode != NULL && pProjectNode == NULL) {
        // Compare current node with given name
        if (strcmp(pNode->project.code, code) == 0) {
            pProjectNode = pNode;
        }
        pNode = pNode->next;
    }
    
    return &(pProjectNode->project);
}

// Add a new project
void projectList_insert(tProjectList* list, tProject project) {
    tProjectNode *pNode = NULL;
    tProjectNode *pPrev = NULL;
    
    assert(list != NULL);
    
    // If the list is empty add the node as first position
    if (list->count == 0) {
        list->first = (tProjectNode*) malloc(sizeof(tProjectNode));
        list->first->next = NULL;
        project_cpy(&(list->first->project), project);
    } else {    
        // Point the first element
        pNode = list->first;
        pPrev = pNode;
                
        // Advance in the list up to the insertion point or the end of the list
        while(pNode != NULL && strcmp(pNode->project.code, project.code) < 0) {            
            pPrev = pNode;
            pNode = pNode->next;
        }
                
        if (pNode == pPrev) {
            // Insert as first element
            list->first = (tProjectNode*) malloc(sizeof(tProjectNode));
            list->first->next = pNode;
            project_cpy(&(list->first->project), project);            
        } else {
            // Insert after pPrev
            pPrev->next = (tProjectNode*) malloc(sizeof(tProjectNode));        
            project_cpy(&(pPrev->next->project), project);
            pPrev->next->next = pNode;            
        }
    }
    list->count ++;
}

// Remove a project
void projectList_del(tProjectList* list, const char* code) {
    tProjectNode *pNode = NULL;
    tProjectNode *pPrev = NULL;
    
    assert(list != NULL);
    assert(code != NULL);
    
    // Check if the list has elements
    if (list->count > 0) {
        pNode = list->first;
        
        // Check if we are removing the first position
        if (strcmp(pNode->project.code, code) == 0) {
            list->first = pNode->next;
        } else {    
            // Search in the list
            pPrev = pNode;
            while (pNode != NULL) {                
                if (strcmp(pNode->project.code, code) == 0) {
                    // Link previous and next nodes
                    pPrev->next = pNode->next;
                    // Remove node
                    project_free(&(pNode->project));
                    free(pNode);
                    list->count --;                    
                    pNode = NULL;
                } else {
                    pPrev = pNode;
                    pNode = pNode->next;
                }                
            }            
        }            
    }
}