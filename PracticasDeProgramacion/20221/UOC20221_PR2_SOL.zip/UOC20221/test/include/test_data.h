#ifndef __TEST_DATA__H
#define __TEST_DATA__H

// Define test data for PR1
const char* test_data_pr1_str = "PERSON;87654321K;John;Smith;john.smith@example.com;My street, 25;Barcelona;30/12/1980\n" \
                            "PERSON;98765432J;Jane;Doe;jane.doe@example.com;Her street, 5;Barcelona;12/01/1995\n" \
                            "PERSON;98232222A;Krunal;Doe;krunal.miracle@example.com;His street, 5;Badalona;21/05/2000\n" \
                            "PERSON;87621123B;Pep;Botera;pepe.botera@example.com;His street, 20;Barcelona;12/01/1972\n" \
                            "CAMPAIGN;01/01/2023;MSF;Medecins Sans Frontieres;Barcelona;MSF0001;12500.00;5\n" \
                            "CAMPAIGN;15/02/2023;CRE;Cruz Roja España;Tortosa;CRE1010;50000;20\n" \
                            "CAMPAIGN;01/01/2023;ACN;ACNUR;Girona;ACN0004;65000.00;50\n" \
                            "CAMPAIGN;20/01/2023;CRE;Cruz Roja España;Olot;CRE1005;25000.00;25\n" \
                            "CAMPAIGN;02/01/2023;MSF;Medecins Sans Frontieres;Berga;MSF0100;27000.00;15\n";                      

// Define test data for PR2
const char* test_data_pr2_str = "PERSON;87654321K;John;Smith;john.smith@example.com;My street, 25;Barcelona;30/12/1980\n" \
                            "PERSON;98765432J;Jane;Doe;jane.doe@example.com;Her street, 5;Barcelona;12/01/1995\n" \
                            "PERSON;98232222A;Krunal;Doe;krunal.miracle@example.com;His street, 5;Badalona;21/05/2000\n" \
                            "PERSON;87621123B;Pep;Botera;pepe.botera@example.com;His street, 20;Barcelona;12/01/1972\n" \
                            "CAMPAIGN;01/01/2023;MSF;Medecins Sans Frontieres;Barcelona;MSF0001;12500.00;5;150000.00\n" \
                            "CAMPAIGN;15/02/2023;CRE;Cruz Roja España;Tortosa;CRE1010;50000;20;500000.00\n" \
                            "CAMPAIGN;01/01/2023;ACN;ACNUR;Girona;ACN0004;65000.00;50;555000.00\n" \
                            "CAMPAIGN;20/01/2023;CRE;Cruz Roja España;Olot;CRE1005;25000.00;25;650000.00\n" \
                            "CAMPAIGN;02/01/2023;MSF;Medecins Sans Frontieres;Berga;MSF0100;27000.00;15;750000.00\n";

// Define test data for PR3
const char* test_data_pr3_str = ""; 

                                                        
#endif // TEST_DATA__H