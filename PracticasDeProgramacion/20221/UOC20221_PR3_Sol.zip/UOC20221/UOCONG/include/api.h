#ifndef __UOCONG_API__H
#define __UOCONG_API__H
#include <stdbool.h>
#include "error.h"
#include "csv.h"

#include "person.h"
#include "project.h"
#include "campaign.h"
#include "ong.h"

// Type that stores all the application data
typedef struct _ApiData {
    ////////////////////////////////
    // PR1 EX2a
    // Staff
    tStaff staff;
    // Projects
    tProjectList projects;
    // CampaignData
    tCampaignData campaignData;

    ////////////////////////////////
    // PR2 EX3a
    tONGList ongs;
    ////////////////////////////////
    
} tApiData;

// Get the API version information
const char* api_version();

// Load data from a CSV file. If reset is true, remove previous data
tApiError api_loadData(tApiData* data, const char* filename, bool reset);

// Add a new entry
tApiError api_addDataEntry(tApiData* data, tCSVEntry entry);

// Free all used memory
tApiError api_freeData(tApiData* data);

// Initialize the data structure
tApiError api_initData(tApiData* data);

// Add a new campaign
tApiError api_addCampaign(tApiData* data, tCSVEntry entry);

// Get the number of people registered on the application
int api_staffCount(tApiData data);

// Get the number of projects registered on the application
int api_projectCount(tApiData data);

// Get the number of campaigns registered on the application
int api_campaignCount(tApiData data);

// Get the number of ngos registered on the application
int api_ongCount(tApiData data);

// Get project data
tApiError api_getProject(tApiData data, const char *code, tCSVEntry *entry);

// Get Campaign data
tApiError api_getCampaign(tApiData data, const char* code, const char* city, tDate date, tCSVEntry *entry);

// Get registered projects
tApiError api_getProjects(tApiData data, tCSVData *projects);

// Get the registered campaings
tApiError api_getCampaigns(tApiData data, tCSVData *campaigns);


////////////////////////////////////////////////////////////////////
// PR3
////////////////////////////////////////////////////////////////////
// Add a new  availability

////
// PR2 - EX2
////
tApiError api_addAvailability(tApiData* data, const char* ongCode, 
const char* document, tDate date);

tApiError api_getPersonAvailability(tApiData* data, const char* document, 
tCSVData *availabilities);

////
// PR2 - EX3
////

// add a new campaign for a certain day
tApiError api_addCampaignDaily(tApiData* data, const char* code, const char* city, const char* projectCode, tDate date);

// returns the staff assigned to a campaign
tApiError api_getStaff2Campaign(tApiData* data, const char* city, const char* projectCode, tDate date, tCSVData *staff);

// list with the staffof the NGO that is available for that date
tApiError api_findStaffAvailable(tApiData* data, const char* ongCode, tDate date, tCSVData *staff);

//retrieve the list with the campaigns of the NGO planned for that date
tApiError api_findCampaigns(tApiData* data, const char* ongCode, tDate date, tCSVData *campaigns);

//search the campaigns planned for that day and the staff available, then assign available staff to the campaign and update staff availability
tApiError api_setStaffCampaigns(tApiData* data, const char* ongCode, tDate date);


#endif // __UOCONG_API__H