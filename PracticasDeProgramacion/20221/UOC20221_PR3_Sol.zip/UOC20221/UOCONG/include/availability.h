#ifndef __AVAILABILITY__H
#define __AVAILABILITY__H
#include "date.h"
#include "person.h"

// Type that stores a vaccination Availability data
typedef struct _tAvailability {    
    // Person
    tPerson* person;
    tDate start;
    tDate end;
} tAvailability;


// Type that stores a list of  availability
typedef struct _tAvailabilityData {    
    //  availabilities
    tAvailability* elems;
    // Number of elements
    int count;    
} tAvailabilityData;

// Initializes a availability data list
void availabilityData_init(tAvailabilityData* list);

// Insert a new availability. Return the position
int availabilityData_insert(tAvailabilityData* list, tPerson* person, tDate date);

// Remove a the availability
void availabilityData_remove(tAvailabilityData* list,  
tPerson* person, tDate date);

// Find the first instance of a Availability for given person
int availabilityData_find(tAvailabilityData* list, tPerson* person, int start_pos);

// Release an Availability data list
void availabilityData_free(tAvailabilityData* list);

// copy dst to src
void availability_copy(tAvailability* dst, tAvailability src);

#endif // __AVAILABILITY__H