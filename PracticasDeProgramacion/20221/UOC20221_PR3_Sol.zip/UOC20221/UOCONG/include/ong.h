#ifndef __ONG_H__
#define __ONG_H__

#include "csv.h"
#include "person.h"
#include "project.h"
#include "campaign.h"
#include "campaignBudget.h"
#include "availability.h"


// NGO 
typedef struct _tONG {    
    char* code;
	char* name;
	tProjectList projects;
	tStaff staff;
	tCampaignBudgetDataList campaignsBudgetData;
	tAvailabilityData staffAvailability;
} tONG;

// NGO list node
typedef struct _tONGNode {    
    tONG elem;
    struct _tONGNode *next;
} tONGNode;

// NGO list node
typedef struct _tONGList {    
    tONGNode* first;
    int count;
} tONGList;


// Initialize a NGO
void ong_init(tONG* ong, const char* code, const char* name);

// Release a NGO's data
void ong_free(tONG* ong);

// Initialize a list of ngos
void ongList_init(tONGList* list);

// Release a list of ngos
void ongList_free(tONGList* list);

// Insert a new ngo
void ongList_insert(tONGList* list, const char* code, const char* name);

// Find a ngo
tONG* ongList_find(tONGList* list, const char* code);

void ongList_print(tONGList* list);


// AUXILIAR METHOD PR2
// Parse input from CSVEntry
void ong_parse(tONG* ong, tCSVEntry entry);

#endif // __ONG_H__