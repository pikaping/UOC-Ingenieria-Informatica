#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include <string.h>
#include "csv.h"
#include "api.h"
#include "person.h"
#include "project.h"
#include "campaign.h"
#include "error.h"

#define FILE_READ_BUFFER_SIZE 2048

// Get the API version information
const char* api_version() {
    return "UOC PP 20221";
}

// Load data from a CSV file. If reset is true, remove previous data
tApiError api_loadData(tApiData* data, const char* filename, bool reset) {
    tApiError error;
    FILE *fin;    
    char buffer[FILE_READ_BUFFER_SIZE];
    tCSVEntry entry;
    
    // Check input data
    assert( data != NULL );
    assert(filename != NULL);
    
    // Reset current data    
    if (reset) {
        // Remove previous information
        error = api_freeData(data);
        if (error != E_SUCCESS) {
            return error;
        }
        
        // Initialize the data
        error = api_initData(data);
        if (error != E_SUCCESS) {
            return error;
        }
    }

    // Open the input file
    fin = fopen(filename, "r");
    if (fin == NULL) {
        return E_FILE_NOT_FOUND;
    }
    
    // Read file line by line
    while (fgets(buffer, FILE_READ_BUFFER_SIZE, fin)) {
        // Remove new line character     
        buffer[strcspn(buffer, "\n\r")] = '\0';
        
        csv_initEntry(&entry);
        csv_parseEntry(&entry, buffer, NULL);
        // Add this new entry to the api Data
        error = api_addDataEntry(data, entry);
        if (error != E_SUCCESS) {
            return error;
        }
        csv_freeEntry(&entry);
    }
    
    fclose(fin);
    
    return E_SUCCESS;
}

// Initialize the data structure
tApiError api_initData(tApiData* data) {            
    //////////////////////////////////
    // Ex PR1 2b
    /////////////////////////////////
    // Check input data structure
    assert(data != NULL);
    
    // Initialize data structures
    staff_init(&(data->staff));
    projectList_init(&(data->projects));
    campaignData_init(&(data->campaignData));

    /////////////////////////////////
	// Ex PR2 3b
    /////////////////////////////////
    ongList_init(&(data->ongs));
        
    return E_SUCCESS;
    
    /////////////////////////////////
    // return E_NOT_IMPLEMENTED;
}

// Add a new campaign
tApiError api_addCampaign(tApiData* data, tCSVEntry entry) {
    //////////////////////////////////
    // Ex PR1 2c
    /////////////////////////////////
    tCampaign campaign;
	tCampaign* newCampaign;
	tProject* pProject;
	tProject project;
    tONG ong;
    tONG* pNgo;

    int ret = E_SUCCESS;
        
    // Check input data structure
    assert(data != NULL);
    
    // Check the entry type
    if (strcmp(csv_getType(&entry), "CAMPAIGN") != 0) {
        return E_INVALID_ENTRY_TYPE;
    }
    
    // Check the number of fields
    if(csv_numFields(entry) != 7 && csv_numFields(entry) != 8) {
        return E_INVALID_ENTRY_FORMAT;
    }
    
    //////////////////////////////////
    // Ex PR2 3d
    /////////////////////////////////
    // Parse the ONG data
    ong_parse(&ong, entry);
    
    pNgo = ongList_find(&(data->ongs), ong.code);
    // Check if ONG exists    
    if (pNgo  == NULL) {
        // Add the ONG
        ongList_insert(&(data->ongs), ong.code, ong.name);
    }     

    // Release ONG data
    ong_free(&ong);
    /////////////////////////////////
    
    // Parse the entry
    campaign_parse(&campaign, entry);
	project_parse(&project, entry);
    	
    // Add the campaign to the data
    ret = campaignData_add(&(data->campaignData), campaign, project.code, &newCampaign);
	if (ret==E_SUCCESS) {        
		// Check if project exists
		pProject = projectList_find(data->projects, project.code);
		if (pProject == NULL) {
			// Add the project
			projectList_insert(&(data->projects), project);
			pProject = projectList_find(data->projects, project.code);
		}
		newCampaign->project = pProject;
		assert(pProject != NULL);
	}

    // Release temporal data
    campaign_free(&campaign);
    project_free(&project);
    return ret;
}

// Get the number of people registered on the application
int api_staffCount(tApiData data) {
    //////////////////////////////////
    // Ex PR1 2d
    /////////////////////////////////
    return staff_len(data.staff);
    /////////////////////////////////
    //return -1;
}

// Get the number of projects registered on the application
int api_projectCount(tApiData data) {
    //////////////////////////////////
    // Ex PR1 2d
    /////////////////////////////////
    return projectList_len(data.projects);    
    /////////////////////////////////
    //return -1;
}

// Get the number of campaigns registered on the application
int api_campaignCount(tApiData data) {
    //////////////////////////////////
    // Ex PR1 2d
    /////////////////////////////////
    return campaignData_len(data.campaignData);
    /////////////////////////////////
    //return -1;
}


// Free all used memory
tApiError api_freeData(tApiData* data) {
    //////////////////////////////////
    // Ex PR1 2e
    /////////////////////////////////
    campaignData_free(&(data->campaignData));
    staff_free(&(data->staff));
    projectList_free(&(data->projects));
    
    //////////////////////////////////
    // Ex PR2 3e
    /////////////////////////////////
    ongList_free(&(data->ongs));
    /////////////////////////////////
    
    
    return E_SUCCESS;
    /////////////////////////////////
    //return E_NOT_IMPLEMENTED;
}


// Add a new entry
tApiError api_addDataEntry(tApiData* data, tCSVEntry entry) { 
    //////////////////////////////////
    // Ex PR1 2f
    /////////////////////////////////
    tPerson person;
        
    assert(data != NULL);
    
    // Initialize the person object
    person_init(&person);
        
    if (strcmp(csv_getType(&entry), "PERSON") == 0) {
        // Check the number of fields
        if(csv_numFields(entry) != 7) {
            return E_INVALID_ENTRY_FORMAT;
        }
        // Parse the data
        person_parse(&person, entry);
        
        // Check if this person already exists
        if (staff_find(data->staff, person.document) >= 0) {
            // Release person object
            person_free(&person);
            return E_DUPLICATED;
        }
        
        // Add the new person
        staff_add(&(data->staff), person);
        
        // Release person object
        person_free(&person);
        
    } else if (strcmp(csv_getType(&entry), "CAMPAIGN") == 0) {
        return api_addCampaign(data, entry);        
    } else {
        return E_INVALID_ENTRY_TYPE;
    }
    return E_SUCCESS;
    /////////////////////////////////
    //return E_NOT_IMPLEMENTED;
}

// Get project data
tApiError api_getProject(tApiData data, const char *name, tCSVEntry *entry) {
    //////////////////////////////////
    // Ex PR1 3a
    /////////////////////////////////
    char buffer[2048];
    tProject* project = NULL;
        
    assert(name != NULL);
    assert(entry != NULL);
    
    // Search the project
    project = projectList_find(data.projects, name);
    
    if (project == NULL) {
        return E_PROJECT_NOT_FOUND;
    }
    

    // Print data in the buffer
    sprintf(buffer, "%s;%s", project->code, project->ongCode);
    
    // Initialize the output structure
    csv_initEntry(entry);
    csv_parseEntry(entry, buffer, "PROJECT");
    
    return E_SUCCESS;
    
}

// Get Campaign
tApiError api_getCampaign(tApiData data, const char* code, const char* city, tDate date, tCSVEntry *entry) {
    //////////////////////////////////
    // Ex PR1 3b
    /////////////////////////////////
    char buffer[2048];
    int idx;
    tCampaign* campaign = NULL;
        
    assert(code != NULL);
	assert(city != NULL);
    assert(entry != NULL);
    
    // Search the campaign
    idx = campaignData_find(data.campaignData, code, city, date);
        
    if (idx < 0) {
        return E_CAMPAIGN_NOT_FOUND;
    }
    
    campaign = &data.campaignData.elems[idx];
	//“codeProject;date;city;cost;numPeople”
	
    // Print data in the buffer
    sprintf(buffer, "%s;%02d/%02d/%04d;%s;%.2f;%d", 
        campaign->project->code, campaign->date.day, campaign->date.month, campaign->date.year,
        campaign->city, campaign->cost, campaign->numPeople
    );
    
    // Initialize the output structure
    csv_initEntry(entry);
    csv_parseEntry(entry, buffer, "CAMPAIGN");
    
    return E_SUCCESS;
    
}

// Get registered projects
tApiError api_getProjects(tApiData data, tCSVData *projects) {
    //////////////////////////////////
    // Ex PR1 3c
    /////////////////////////////////
    char buffer[2048];
    tProjectNode *pNode = NULL;
    
    csv_init(projects);
        
    pNode = data.projects.first;
    while(pNode != NULL) {
        sprintf(buffer, "%s;%s", pNode->project.code, pNode->project.ongCode);
        csv_addStrEntry(projects, buffer, "PROJECT");
        pNode = pNode->next;
    }    
    
    return E_SUCCESS;
}

// Get campaigns
tApiError api_getCampaigns(tApiData data, tCSVData *campaigns) {
    //////////////////////////////////
    // Ex PR1 3d
    /////////////////////////////////
    char buffer[2048];
    int idx;
    
    csv_init(campaigns);
    for(idx=0; idx<data.campaignData.count ; idx++) {
        sprintf(buffer, "%s;%02d/%02d/%04d;%s;%.2f;%d", 
            data.campaignData.elems[idx].project->code,
			data.campaignData.elems[idx].date.day, data.campaignData.elems[idx].date.month, data.campaignData.elems[idx].date.year,
            data.campaignData.elems[idx].city, data.campaignData.elems[idx].cost, data.campaignData.elems[idx].numPeople
        );
        csv_addStrEntry(campaigns, buffer, "CAMPAIGN");
    }
    
    return E_SUCCESS;
}


// Get the number of ngos registered on the application
int api_ongCount(tApiData data) {
    //////////////////////////////////
    // Ex PR2 3c
    
    return data.ongs.count;
    
    /////////////////////////////////
    // return -1;
}


// Add a new  availability
tApiError api_addAvailability(tApiData* data, const char* ongCode, 
const char* document, tDate date) {
    //////////////////////////////////
    // Ex PR3 2c
    /////////////////////////////////

    tPerson* pPerson = NULL;    
    tONG* pOng;
    int pos = -1;

    // Check input data
    assert(data != NULL);
    assert(document != NULL);
    assert(ongCode != NULL);

    
    // Search person
    pPerson = staff_findPerson(data->staff, document);
    if (pPerson == NULL ) {
        return E_PERSON_NOT_FOUND;
    }
    
    // Search the NGO
    pOng= ongList_find(&(data->ongs), ongCode);
    if (pOng == NULL) {
        return E_ONG_NOT_FOUND;
    }
    
	// insert a new availability
    pos = availabilityData_insert(&(pOng->staffAvailability), pPerson, date);
    
    // If/else using one line
    return (pos>=0?E_SUCCESS:E_ERROR);
    /////////////////////////////////
    // return E_NOT_IMPLEMENTED; 
    /////////////////////////////////    
}

// Get person availabilities
tApiError api_getPersonAvailability(tApiData* data, const char* document,
 tCSVData *availabilities) {
    //////////////////////////////////
    // Ex PR3 2c
    /////////////////////////////////
    char buffer[2048];
    tPerson* pPerson = NULL;
    tONGList* ongs = NULL;
    tONGNode *pNode = NULL;    
    int pos = 0;
    tAvailability* pAvailability;

    // Check input data    
    assert(document != NULL);
    assert(availabilities != NULL);
    
    // Initialize the data
    csv_init(availabilities);
    
    // Search person
    pPerson = staff_findPerson(data->staff, document);

    if (pPerson == NULL) {
        return E_PERSON_NOT_FOUND;
    }

    csv_init(availabilities);

    ongs = &(data->ongs);
    pNode = ongs->first;

    // Search availabilities in each ngo
    while (pNode!=NULL) {
        pos = availabilityData_find(&(pNode->elem.staffAvailability), pPerson, pos);
        pAvailability = &(pNode->elem.staffAvailability.elems[pos]);

		// search availabilities in the same ngo
        while (pos>=0) {
    
            sprintf(buffer, "%02d/%02d/%04d;%02d/%02d/%04d;%s",
            pAvailability->start.day, pAvailability->start.month, pAvailability->start.year,
            pAvailability->end.day, pAvailability->end.month, pAvailability->end.year,
            pNode->elem.code);
            // Add this string to the report                
            
            csv_addStrEntry(availabilities, buffer, "AVAILABILITY");   

            pos = availabilityData_find(&(pNode->elem.staffAvailability), pPerson, pos+1);
            pAvailability = &(pNode->elem.staffAvailability.elems[pos]);
        }

        pNode = pNode->next;     
        pos = 0;
    }  
    
    return E_SUCCESS;
    
    /////////////////////////////////
    /// return E_NOT_IMPLEMENTED; 
    /////////////////////////////////
}

tApiError api_addCampaignDaily(tApiData* data, const char* ongCode, const char* city, const char* projectCode, tDate date) {
    tCampaign* pCampaign = NULL;
    tONGList* ongs = NULL;
    tONG* theNGO;
    tCampaignBudgetDataList* pCampaignBudgetDataList;

    ongs = &(data->ongs);
    theNGO = ongList_find(ongs, ongCode);

    if (theNGO == NULL) {
        return E_ONG_NOT_FOUND;
    }
    pCampaignBudgetDataList = &(theNGO->campaignsBudgetData);
    pCampaign = campaignData_findCampaign(data->campaignData, projectCode, city, date); 

    if (pCampaign != NULL) {
       return campaignBudgetDataList_add(pCampaignBudgetDataList, date, pCampaign);
    }
    else {
        return E_CAMPAIGN_NOT_FOUND;
    }

    return E_SUCCESS;
    /////////////////////////////////
    /// return E_NOT_IMPLEMENTED; 
    /////////////////////////////////
}

// get the staff availability, on a given date for an NGO
void findStaffAvailable(tApiData* data, const char* ongCode, tDate date, tStaff* staff) {
    tAvailabilityData* availabilityData;
    tAvailability* pAvailability;
    tPerson* pPerson;
    tONGList* ongs = NULL;
    tONG* theNGO;
    
    int i = 0;

    ongs = &(data->ongs);
	
	// find the NGO
    theNGO = ongList_find(ongs, ongCode);

	// get the availability data
    availabilityData = &(theNGO->staffAvailability);

    while ( i < availabilityData->count) {
        pAvailability = &(availabilityData->elems[i]);
        pPerson = pAvailability->person;
        if (date_isInRange(date, pAvailability->start, pAvailability->end)) {
            staff_add(staff, *pPerson);
        }
        i++;
    } 
}

tApiError api_findStaffAvailable(tApiData* data, const char* ongCode, tDate date, tCSVData *staffCSVData) {
    //////////////////////////////////
    // Ex PR3 3a
    /////////////////////////////////
    char buffer[2048];
    tONGList* ongs = NULL;
    tONG* theNGO;
    tPerson* pPerson;
    tStaff staff;

    int i = 0;

    // Check input data    
    assert(ongCode != NULL);
    assert(staffCSVData != NULL);

    csv_init(staffCSVData);

    ongs = &(data->ongs);
    theNGO = ongList_find(ongs, ongCode);

    if (theNGO == NULL) {
        return E_ONG_NOT_FOUND;
    }

    staff_init(&staff);
    // get the staff availability, on a given date for an NGO
    findStaffAvailable(data, ongCode, date, &staff);
    while (i < staff.count) {
        pPerson = &(staff.elems[i]);
        sprintf(buffer, "%s;%s;%s;%s;%s;%s;%02d/%02d/%04d",
              pPerson->document, pPerson->name, pPerson->surname, pPerson->email,
              pPerson->address, pPerson->city, pPerson->birthday.day, pPerson->birthday.month, 
              pPerson->birthday.year);

        csv_addStrEntry(staffCSVData, buffer, "PERSON");   

        i++;
    }
    staff_free(&staff);

    return E_SUCCESS;
    
    /////////////////////////////////
    /// return E_NOT_IMPLEMENTED; 
    /////////////////////////////////
}

tApiError api_findCampaigns(tApiData* data, const char* ongCode, tDate date, tCSVData *campaigns) {
    char buffer[2048];
    tONGList* ongs = NULL;
    tONG* theNGO;
    tCampaignBudgetDataList* pCampaignBudgetDataList;
    tCampaignDaily* campaignDaily;
    tCampaignNode* pNext;
    tCampaign* pCampaign;

    //////////////////////////////////
    // Ex PR3 3b
    /////////////////////////////////

    // Check input data    
    assert(campaigns != NULL);
    assert(ongCode != NULL);

    csv_init(campaigns);

    ongs = &(data->ongs);
    
	//  get the NGO
	theNGO = ongList_find(ongs, ongCode);

    if (theNGO == NULL) {
        return E_ONG_NOT_FOUND;
    }

    pCampaignBudgetDataList = &(theNGO->campaignsBudgetData);
    campaignDaily = campaignBudgetDataList_getCampaignDaily(pCampaignBudgetDataList, date);
    pNext = campaignDaily->first;

    csv_init(campaigns);
	
	// Search the campaigns for a given date
    while (pNext!=NULL) {
        pCampaign = pNext->elem;
        
        sprintf(buffer, "%02d/%02d/%04d;%s;%s;%d",
              pCampaign->date.day, pCampaign->date.month, pCampaign->date.year,
              pCampaign->project->ongCode, pCampaign->city, pCampaign->numPeople);

        csv_addStrEntry(campaigns, buffer, "CAMPAIGN");

        pNext = pNext->next;
    }
    return E_SUCCESS;
    
    /////////////////////////////////
    /// return E_NOT_IMPLEMENTED; 
    /////////////////////////////////
}

tApiError api_getStaff2Campaign(tApiData* data, const char* city, const char* projectCode, tDate date, tCSVData *staffCSVData){
    //////////////////////////////////
    // Ex PR3 3d
    //////////////////////////////////
    char buffer[2048];
    tCampaign* pCampaign;
    tStaff* pStaff;
    tPerson* pPerson;
    int i = 0;

	// get the campaing
    pCampaign = campaignData_findCampaign(data->campaignData, projectCode, city, date); 

    csv_init(staffCSVData);

    pStaff = pCampaign->staff;
    if (pStaff!=NULL) {
		
		// List the staff available
        while (i < pStaff->count) {
            pPerson = &(pStaff->elems[i]);
            sprintf(buffer, "%s;%s;%s;%s;%s;%s;%02d/%02d/%04d",
                pPerson->document, pPerson->name, pPerson->surname, pPerson->email,
                pPerson->address, pPerson->city, pPerson->birthday.day, pPerson->birthday.month, 
                pPerson->birthday.year);

            csv_addStrEntry(staffCSVData, buffer, "PERSON");   

            i++;
        }
    }
    return E_SUCCESS;    
    /////////////////////////////////
    /// return E_NOT_IMPLEMENTED; 
    /////////////////////////////////
}

tApiError api_setStaffCampaigns(tApiData* data, const char* ongCode, tDate date){
    //////////////////////////////////
    // Ex PR3 3c
    //////////////////////////////////
    tAvailabilityData* availabilityData;
    tCampaignBudgetDataList* pCampaignBudgetDataList;
    tCampaignDaily* campaignDaily;
    tCampaignNode* pNext;
    tCampaign* pCampaign;
    tPerson* pPerson;
    tONGList* ongs = NULL;
    tONG* theNGO;
    tStaff staff;
    tStaff *staffCampaign;
	tPerson person;
    bool hasStaff = true;
    int numStaff = 0;
    int i = 0;
    int iStaff = 0;

    // Check input data    
    assert(ongCode != NULL);

    ongs = &(data->ongs);
	
	// Get the NGO
    theNGO = ongList_find(ongs, ongCode);

    if (theNGO == NULL) {
        return E_ONG_NOT_FOUND;
    }
	
	// Get the available data
    availabilityData = &(theNGO->staffAvailability);

    pCampaignBudgetDataList = &(theNGO->campaignsBudgetData);
    campaignDaily = campaignBudgetDataList_getCampaignDaily(pCampaignBudgetDataList, date);
  
    staff_init(&staff);

    // get the staff availability, on a given date for an NGO
    findStaffAvailable(data, ongCode, date, &staff);
    numStaff = staff.count;

    pNext = campaignDaily->first;
    hasStaff = iStaff<numStaff;
    if (!hasStaff) {
		return E_NO_AVAILABLE;
	}
	
    while (pNext!=NULL && hasStaff ) {
        pCampaign = pNext->elem;
		if (pCampaign->numPeople > staff.count) {
			return E_NO_AVAILABLE;
		}
        i = 0;

		// initialice the staff array for the campaign
        staffCampaign = malloc(sizeof(tStaff));
        assert(staffCampaign != NULL);
        staff_init(staffCampaign);
        while (i < pCampaign->numPeople && hasStaff ) {
            pPerson = &(staff.elems[iStaff]);

			person_init(&person);
			person_cpy(&person, *pPerson);
			
			// Add the person to the campaign
            staff_add(staffCampaign, person);
			
			// remove the person availibility for the given date 
            availabilityData_remove(availabilityData, pPerson, date);
            
            iStaff++;
            i++;
            hasStaff = iStaff < numStaff;
            
            person_free(&person);
        }
        pCampaign->staff = staffCampaign;        
        pNext = pNext->next;
    }
    
    staff_free(&staff);

    return E_SUCCESS;
    
    /////////////////////////////////
    /// return E_NOT_IMPLEMENTED; 
    /////////////////////////////////
}
