#include <string.h>
#include <assert.h>
#include <stdlib.h>
#include <stdio.h>
#include "availability.h"
#include "date.h"
#include "person.h"

// Initializes a availability data list
void availabilityData_init(tAvailabilityData* list){
    //////////////////////////////////
    // Ex PR3 1a
    /////////////////////////////////
    assert(list != NULL);
    list->count = 0;
    list->elems = NULL;
}

// Makes a copy of tAvailability data
void availability_copy(tAvailability* dst, tAvailability src) {
    dst->person = src.person;
    dst->start = src.start;
    dst->end = src.end;
}

int availability_get_insertion_point(tAvailabilityData* list, tPerson* person, tDate date) {
    bool found = false;
    tAvailability* p = NULL;
    int i = 0;
    while ( i< list->count && !found) {
        p = &(list->elems[i]);
        found = (strcmp(p->person->document, person->document)==0 && 
                 date_isInRangePlusOne(date, p->start, p->end) );
        if (!found) i++;
    }
    
    // Operator ? allows to write an if/else using only one line
    return (found?i: -1);
}

bool isBefore(tAvailability* pAvailability, tDate date) {
    tDate dateAux;
    date_copy(&dateAux, &date);
    
    date_addDay(&date, +1);
    return (date_cmp(pAvailability->start, date)==0);
}

bool isAfter(tAvailability* pAvailability, tDate date) {
    tDate dateAux;
    date_copy(&dateAux, &date);
    
    date_addDay(&date, -1);
    return (date_cmp(pAvailability->end, date)==0);
}

bool isInRange(tAvailability* pAvailability, tDate date) {
    bool ret = false;
    ret = (date_cmp(date, pAvailability->start)>=0 && date_cmp(date, pAvailability->end)<=0);
    return ret;
}

void availabilityData_merge(tAvailabilityData* list, tPerson* person, int insert_pos) {
    tAvailability* pFirst;
    tAvailability* pSecond;
    int secondPos = 0;
    int i = 0;
    
    pFirst = &(list->elems[insert_pos]);
    
    secondPos = availabilityData_find(list, person, insert_pos+1);    
    if (secondPos >= 0) {
        pSecond = &(list->elems[secondPos]);
        
        if (dates_are_consecutives(pFirst->end, pSecond->start)) {
            pFirst->end = pSecond->end;
            // Displace all elements from end to the insertion position    

            for (i=list->count - 1; i>secondPos; i--) {
                    list->elems[i] = list->elems[i-1];
            }    

            list->count--;
            list->elems = (tAvailability*) realloc(list->elems, list->count * sizeof(tAvailability));
        }        
    }
}

void availabilityData_swap(tAvailabilityData* list, int insert_pos, int insert_pos_swap) {
    tAvailability pAvailabilityAux;
    
    availability_copy(&pAvailabilityAux, list->elems[insert_pos_swap]);
    
    list->elems[insert_pos_swap] = list->elems[insert_pos];
    list->elems[insert_pos] = pAvailabilityAux; 
    
}

void  availabilityData_sort(tAvailabilityData* list, int *insert_pos){
    int i = *insert_pos;
	
    while ( i>0 && date_cmp(list->elems[i-1].start, list->elems[i].start) > 0 ) {
		availabilityData_swap(list, i, i-1);
        i--;
    }
    
    *insert_pos = i;
}

void  availabilityData_sortByRight(tAvailabilityData* list, int* insert_pos){
    int i = *insert_pos;  

    while ( i<list->count-1 && date_cmp(list->elems[i].start, list->elems[i+1].start) > 0 ) {
        availabilityData_swap(list, i, i+1);
        i++;
    }
    
    *insert_pos = i;
}

// Insert a new  Availability
int availabilityData_insert(tAvailabilityData* list, tPerson* person, tDate date) {
    //////////////////////////////////
    // Ex PR3 1b
    /////////////////////////////////
    int insert_pos = -1;
    tAvailability* currrentAvailability = NULL;

    // Check input data
    assert(list != NULL);
    assert(person != NULL);
    
    // Allocate memory for new element
    if (list->count == 0) {
        // Request new memory space
        list->elems = (tAvailability*) malloc(sizeof(tAvailability));
        list->elems[0].person = person;
        list->elems[0].start = date;
        list->elems[0].end = date;
        list->count++;
        insert_pos = 0;
    } 
    else { 
		
		// check if "person" has already an availability with the given "date"
        insert_pos = availability_get_insertion_point(list, person, date);
		
		if (insert_pos>=0) {
            currrentAvailability = &(list->elems[insert_pos]);
            
			// expandLeft 
			if (currrentAvailability!=NULL && isBefore(currrentAvailability, date)) {
                currrentAvailability->start = date;
            }
			// expandRight
            else if (currrentAvailability!=NULL && isAfter(currrentAvailability, date)) {
                currrentAvailability->end = date;
            }
            else if (currrentAvailability!=NULL && isInRange(currrentAvailability, date)){
                // do nothing
            }            
        }
        else {
           // Modify currently allocated memory
            list->elems = (tAvailability*) realloc(list->elems, (list->count + 1) * sizeof(tAvailability));
            // In case insertion point is not found, set as last element
            insert_pos = list->count;
            // Increase the size of the list
            list->count++;
            // Finally add the new element
            list->elems[insert_pos].person = person;
            list->elems[insert_pos].start = date;
            list->elems[insert_pos].end = date;
        }
		
		// move the availability in the right position
        availabilityData_sort(list, &insert_pos);
		
		// Check if two availabilities with an adjacent date, merge them
        availabilityData_merge(list, person, insert_pos); 
    }
    assert(list->elems != NULL);
	
	// return the position of the current availability
    return insert_pos;
}

void availabilityData_split(tAvailabilityData* list, tDate date, int* insert_pos) {
	int i = 0;
	tDate endDate;
	tDate* pEndDate;
	int pos = 0;
	
	pos = *insert_pos;
	
    // Modify currently allocated memory
    list->elems = (tAvailability*) realloc(list->elems, (list->count + 1) * sizeof(tAvailability));
	// Displace all elements from end to the insertion position    

    // Increase the size of the list
    list->count++;
	
	for(i=list->count - 1; i > pos; i--) {
        list->elems[i] = list->elems[i-1];
    }    
	
	pEndDate = &(list->elems[pos].end);
	date_copy(&endDate, pEndDate);

	date_addDay(&date, -1);	
	list->elems[pos].end = date;
	
    // Finally add the new element
	date_addDay(&date, +2);
	
    list->elems[pos + 1].start = date;
    list->elems[pos + 1].end = endDate;
	*insert_pos = pos +1;
}

// Remove a  Availability
void availabilityData_remove(tAvailabilityData* list, tPerson* person, tDate date) {
    //////////////////////////////////
    // Ex PR3 1c
    /////////////////////////////////

    int insert_pos = 0;
    int i = 0;
    tAvailability* currrentAvailability = NULL;

    
	// check if "person" has already an availability with the given "date"
    insert_pos = availability_get_insertion_point(list, person, date);
    if (insert_pos>=0) {

        currrentAvailability = &(list->elems[insert_pos]);

        if (date_cmp(currrentAvailability->start, date)==0 &&
              date_cmp(currrentAvailability->end, date)==0 ) {
            // Displace all elements from end to the insertion position    
            for(i = insert_pos; i < list->count-1; i++) {
                list->elems[i] = list->elems[i+1];
            }

			// empty list
            if (list->count == 0) {
                free(list->elems);
                list->elems = NULL;
            }
            else {
                list->count--;
                // Modify currently allocated memory
                list->elems = (tAvailability*) realloc(list->elems, list->count * sizeof(tAvailability));
                assert(list->elems != NULL);
            }
        }
		// reduce range (left)
		else if (date_cmp(currrentAvailability->start, date) == 0) {
            date_addDay(&date, +1);
            currrentAvailability->start = date;
        }    
		// reduce range (right)
        else if (date_cmp(currrentAvailability->end, date)==0) {
            date_addDay(&date, -1);
            currrentAvailability->end = date;
        }
		// Split the range
        else {
            availabilityData_split(list, date, &insert_pos); 
        }
		
		// move the availability in the right position
		availabilityData_sortByRight(list, &insert_pos);

    }
}

// Find the first instance of a Availability for given person
int availabilityData_find(tAvailabilityData* list, tPerson* person, 
int start_pos) {
    //////////////////////////////////
    // Ex PR3 1d
    /////////////////////////////////
    int pos=0;
    
    // Check input data
    assert(list != NULL);
    assert(person != NULL);
    
    // Trivial cases
    if (start_pos >= list->count) {
        // Trivial case 1: Start position larger than number of elements
        pos = -1;
    } else if(strcmp(list->elems[start_pos].person->document, person->document) == 0) {
        // Trivial case 2: Current position is the element we are looking for
        pos = start_pos;
    } else {
        // Recursive call
        pos = availabilityData_find(list, person, start_pos + 1);
    }
    
    return pos;
}

// Release an Availability data list
void availabilityData_free(tAvailabilityData* list) {
    //////////////////////////////////
    // Ex PR3 1e
    /////////////////////////////////
    assert(list != NULL);
    if (list->elems != NULL) {
        // Release memory
        free(list->elems);        
    }
    list->elems = NULL;
    list->count = 0;
}
