#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include <stdio.h>
#include "campaign.h"
#include "project.h"
#include "error.h"


// Initialize compaign 
void campaign_init(tCampaign* campaign, tProject* project, tDate date, const char* city, float cost, int numPeople){
    assert(campaign != NULL);
    assert(city != NULL);
    
    // Allocate memory for the cp
    campaign->city = (char*) malloc(strlen(city) + 1);
	memset(campaign->city, 0, strlen(city)+1);
    assert(campaign->city != NULL);
    
    // Set the data
    strcpy(campaign->city, city);
    campaign->project = project;
    campaign->date = date;
    campaign->numPeople = numPeople;
    campaign->cost = cost;
    
    campaign->staff = NULL;
}


// Release campaign data
void campaign_free(tCampaign* campaign) {
    assert(campaign != NULL);
    
    // Release used memory
    if (campaign->city != NULL) {
        free(campaign->city);
        campaign->city = NULL;
    }
    campaign->project = NULL;
    
    if (campaign->staff != NULL){ 
        staff_free(campaign->staff);
        free(campaign->staff);
        campaign->staff = NULL;
    }
}

// Copy the data of a campaign from the source to destination
void campaign_cpy(tCampaign* destination, tCampaign source) {
    assert(destination != NULL);
    
    // Set the data
    campaign_init(destination, source.project, source.date, source.city, source.cost, source.numPeople);
}

// Parse input from CSVEntry
void campaign_parse(tCampaign* campaign, tCSVEntry entry) {
    char sDate[11];
	char* city;
	tDate date;
	float cost;
	int numPeople;

    // Check input data
    assert(campaign != NULL);
    assert(csv_numFields(entry) == 7 || csv_numFields(entry) == 8);
	
	// city
	city = entry_getString(&entry, 3);

	// date
    csv_getAsString(entry, 0, sDate, 11);
    date_parse(&date, sDate);

	// cost
    cost = csv_getAsReal(entry, 5);

	// numPeople
	numPeople = csv_getAsInteger(entry, 6);
    
    // Initialize the campaign structure
    campaign_init(campaign, NULL, date, city, cost, numPeople);
    
    free(city);
}

// Initialize the campaign data
void campaignData_init(tCampaignData* data) {
    assert(data != NULL);

    // Set the initial number of elements to zero.
    data->count = 0;
    data->elems = NULL;
}

// Remove all elements
void campaignData_free(tCampaignData* data) {
    int i;
    if (data->elems != NULL) {
        for(i=0; i < data->count; i++) {
            campaign_free(&(data->elems[i]));
        }
        free(data->elems);
    }
    campaignData_init(data);
}

int campaignData_len(tCampaignData data) {
    // Return the number of campaings
    return data.count;
}

// Add a new campaign
int campaignData_add(tCampaignData* data, tCampaign campaign, const char* projectCode, tCampaign** newCampaign) {
    int idx = -1;

    // Check input data (Pre-conditions)
    assert(data != NULL);

    // Check if an entry with this data already exists
    idx = campaignData_find(*data, projectCode, campaign.city, campaign.date);

    // If it does not exist, create a new entry, otherwise return E_DUPLICATED.
    if (idx < 0) {
        if (data->elems == NULL) {
            data->elems = (tCampaign*) malloc(sizeof(tCampaign));
        } else {
            data->elems = (tCampaign*) realloc(data->elems, (data->count + 1) * sizeof(tCampaign));
        }
        assert(data->elems != NULL);
        campaign_cpy(&(data->elems[data->count]), campaign);
                *newCampaign = &(data->elems[data->count]);
        data->count ++;
    } else {
        return E_DUPLICATED;
    }
    return E_SUCCESS;
}


// Remove campaign data
void campaignData_del(tCampaignData* data, const char* code, const char* city, tDate date, int numPeople, float cost) {
    int idx;
    int i;

    assert(code != NULL);
    assert(city != NULL);

    // Check if an entry with this data already exists
    idx = campaignData_find(*data, code, city, date);

    if (idx >= 0) {
        // Reduce the cost
        data->elems[idx].cost -= cost;
        // Shift elements to remove selected
        if (data->elems[idx].cost <= 0) {
            for(i = idx; i < data->count-1; i++) {
                // Remove the data from this position
                campaign_free(&(data->elems[i]));
                // Copy element on position i+1 to position i
                campaign_cpy(&(data->elems[i]), data->elems[i+1]);
            }
            // Update the number of elements
            data->count--;
            // Free last position
            campaign_free(&(data->elems[data->count]));
        }
        if (data->count > 0) {
            data->elems = (tCampaign*) realloc(data->elems, data->count * sizeof(tCampaignData));
            assert(data->elems != NULL);
        } else {
            free(data->elems);
            data->elems = NULL;
        }
    }
}

// Return the position of a campaign entry with provided information. -1 if it does not exist
int campaignData_find(tCampaignData data, const char* code, const char*city, tDate date) {
    int i;
    bool found;
	char* _city;
	char* _code;
    assert(code != NULL);
    assert(city != NULL);
    found = false;
    i=0;

    while (!found && i < data.count) {
		_code = data.elems[i].project->code;
		_city = data.elems[i].city;

		found = (strcmp(_code, code)==0) &&
                (strcmp(_city, city)==0) &&
                (date_cmp(data.elems[i].date, date)==0);

        if (!found) i++;
    }

    return (found?i:-1);
}

tCampaign* campaignData_findCampaign(tCampaignData data, const char* code, const char*city, tDate date) {
  int idx = campaignData_find(data, code, city, date);

  return (idx!=-1?&(data.elems[idx]):NULL);
}

