#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include "ong.h"


// Initialize a NGO
void ong_init(tONG* ong, const char* code, const char* name){ 
	assert(ong != NULL);
    assert(code != NULL);
	assert(name != NULL);

	// Allocate memory for the code
    ong->code = (char*) malloc(strlen(code) + 1);
	memset(ong->code, 0, strlen(code)+1);
    assert(ong->code != NULL);
    strcpy(ong->code, code);    
	
	// Allocate memory for the name
    ong->name = (char*) malloc(strlen(name) + 1);
	memset(ong->name, 0, strlen(name)+1);
    assert(ong->name != NULL);
	strcpy(ong->name, name);
    
    // Initialize projects
    projectList_init(&(ong->projects));
    
    // Initialize staff
	staff_init(&(ong->staff));
    
    // Initialize campaigns
	campaignBudgetDataList_init(&(ong->campaignsBudgetData));

    //////////////////////////////////
    // Ex PR3 2a
    /////////////////////////////////
    
    // Initialize availability
    availabilityData_init(&(ong->staffAvailability)); 
}

// Release a NGO's data
void ong_free(tONG* ong){
	 assert(ong != NULL);
    
    // Release code memory
    if(ong->code != NULL) {
        free(ong->code);
        ong->code = NULL;        
    }

	 // Release name memory
    if(ong->name != NULL) {
        free(ong->name);
        ong->name = NULL;        
    }
    
    // Remove projectList
    projectList_free(&(ong->projects));   

     // Remove staff
	staff_init(&(ong->staff));

	 // Remove campaings
    campaignBudgetDataList_free(&(ong->campaignsBudgetData));
    

    //////////////////////////////////
    // Ex PR3 2a
    /////////////////////////////////

	// Remove staffAvailability
    availabilityData_free(&(ong->staffAvailability));
}

// Initialize a list of ngos
void ongList_init(tONGList* list){
	 assert(list != NULL);
    
     list->first = NULL;
     list->count = 0;

}

// Release a list of ngos
void ongList_free(tONGList* list){
	
	tONGNode *pNode = NULL;
    tONGNode *pAux = NULL;
    
    assert(list != NULL);
    
    pNode = list->first;
    while(pNode != NULL) {
        // Store the position of the current node
        pAux = pNode;
        
        // Move to the next node in the list
        pNode = pNode->next;
        
        // Remove previous node
        ong_free(&(pAux->elem));
        free(pAux);
    }
    
    // Initialize to an empty list
    ongList_init(list);

}

// Insert a new ngo
void ongList_insert(tONGList* list, const char* code, const char* name){ 	    
  
	tONGNode *pNode;
    tONGNode *pAux;
    
    assert(list != NULL);
    assert(code != NULL);
	assert(name != NULL);
    
    if (ongList_find(list, code) == NULL) {    
        
        // Check if insertion point is the first position
        if (list->first == NULL || strcmp(list->first->elem.code, code) > 0) {
            // Insert as initial position
            pAux = list->first;            
            list->first = (tONGNode*) malloc(sizeof(tONGNode));
            assert(list->first != NULL);
            list->first->next = pAux;
            ong_init(&(list->first->elem), code, name);
        } else {        
            // Search insertion point
            pAux = list->first;
            pNode = pAux->next;            
            while(pNode != NULL && strcmp(pNode->elem.code, code) > 0) {                
                pAux = pNode;
                pNode = pNode->next;         
            }
            pAux->next = (tONGNode*) malloc(sizeof(tONGNode));
            assert(pAux->next != NULL);
            pAux->next->next = pNode;          
            ong_init(&(pAux->next->elem), code, name);
        }
        // Increase the number of elements
        list->count++;
    }
	

}

// Find a ngo
tONG* ongList_find(tONGList* list, const char* code){
	tONGNode *pNode;    
    tONG *pONG;    
    
    assert(list != NULL);
    
    // Search center with provided code
    pNode = list->first;
    pONG = NULL;
    while(pNode != NULL && pONG == NULL) {
        if(strcmp(code, pNode->elem.code) == 0) {
            pONG = &(pNode->elem);
        }        
        pNode = pNode->next;        
    }
    
    return pONG;
}
    
void ongList_print(tONGList* list){
	tONGNode *pNode;    
    tONG *pONG;    
    
    assert(list != NULL);
    
    pNode = list->first;
    pONG = NULL;
    while(pNode != NULL && pONG == NULL) {        
        printf("ong %s code %s\n",pNode->elem.name,pNode->elem.code);      
        pNode = pNode->next;        
    }
}


// Parse input from CSVEntry  (AUX METHOD PR2)
void ong_parse(tONG* ong, tCSVEntry entry) {
    char *code;
    char *name;
    
    // Check input data
    assert(ong != NULL);
    
    // Check entry fields
    assert(csv_numFields(entry) == 7 || csv_numFields(entry) == 8 );
         
    // Copy ONG code
    code = (char*) malloc((strlen(entry.fields[1]) + 1) * sizeof(char));
    assert(code != NULL);
    memset(code, 0, (strlen(entry.fields[1]) + 1) * sizeof(char));
    csv_getAsString(entry, 1, code, strlen(entry.fields[1]) + 1);
    
    // Copy ONG name
    name = (char*) malloc((strlen(entry.fields[2]) + 1) * sizeof(char));
    assert(name != NULL);
    memset(name, 0, (strlen(entry.fields[2]) + 1) * sizeof(char));
    csv_getAsString(entry, 2, name, strlen(entry.fields[2]) + 1);
    
    // Initialize the NGO with entry data
    ong_init(ong, code, name);
    
    // Remove temporal fields
    free(name);
    free(code);
}   