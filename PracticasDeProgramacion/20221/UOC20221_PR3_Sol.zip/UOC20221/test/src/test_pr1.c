#include <assert.h>
#include <stdlib.h>
#include <string.h>
#include "test_pr1.h"
#include "api.h"

// Run all tests for PR1
bool run_pr1(tTestSuite* test_suite, const char* input) {
    bool ok = true;
    tTestSection* section = NULL;

    assert(test_suite != NULL);

    testSuite_addSection(test_suite, "PR1", "Tests for PR1 exercices");

    section = testSuite_getSection(test_suite, "PR1");
    assert(section != NULL);

    ok = run_pr1_ex1(section, input);
    ok = run_pr1_ex2(section, input) && ok;
    ok = run_pr1_ex3(section, input) && ok;

    return ok;
}

// Run all tests for Exercice 1 of PR1
bool run_pr1_ex1(tTestSection* test_section, const char* input) {
    bool passed = true, failed = false;
    const char* version;
    
    /////////////////////////////
    /////  PR1 EX1 TEST 1  //////
    /////////////////////////////
    failed = false;
    start_test(test_section, "PR1_EX1_1", "Read version information.");
    // Get the version
    version = api_version();
    if (strcmp(version, "UOC PP 20221") != 0) {
        failed = true;
        passed = false;
    }
    end_test(test_section, "PR1_EX1_1", !failed);
    
    return passed;
}

// Run all tests for Exercice 2 of PR1
bool run_pr1_ex2(tTestSection* test_section, const char* input) {
    
    tApiData data;
    tApiError error;
    tCSVEntry entry;
	int nCampaigns;
	int nProjects;
    bool passed = true;
    bool failed = false;
    bool fail_all = false;

    /////////////////////////////
    /////  PR1 EX2 TEST 1  //////
    /////////////////////////////
    failed = false;
    start_test(test_section, "PR1_EX2_1", "Initialize the API data structure");
    // Initialize the data
    error = api_initData(&data);
    if (error != E_SUCCESS) {
        failed = true;
        passed = false;
        fail_all = true;
    }
    end_test(test_section, "PR1_EX2_1", !failed);


    /////////////////////////////
    /////  PR1 EX2 TEST 2  //////
    /////////////////////////////
    failed = false;
    start_test(test_section, "PR1_EX2_2", "Add a valid campaign and a project");
    if (fail_all) {
        failed = true;
    } else {
        csv_initEntry(&entry);
        csv_parseEntry(&entry,  "01/01/2023;MSF;Medecins Sans Frontieres;Barcelona;MSF0001;12500.00;5", "CAMPAIGN");
        error = api_addCampaign(&data, entry);
        if (error != E_SUCCESS) {
            failed = true;
            passed = false;
            fail_all = true;
        }
        csv_freeEntry(&entry);

    }
    end_test(test_section, "PR1_EX2_2", !failed);

    /////////////////////////////
    /////  PR1 EX2 TEST 3  //////
    /////////////////////////////
    failed = false;
    start_test(test_section, "PR1_EX2_3", "Add an existent campaign ");
    if (fail_all) {
        failed = true;
    } else {
        csv_initEntry(&entry);
        csv_parseEntry(&entry,  "01/01/2023;MSF;Medecins Sans Frontieres;Barcelona;MSF0001;12500.00;5", "CAMPAIGN");
        error = api_addCampaign(&data, entry);
        if (error != E_DUPLICATED) {
            failed = true;
            passed = false;
            fail_all = true;
        }
        csv_freeEntry(&entry);
    }
    end_test(test_section, "PR1_EX2_3", !failed);

    /////////////////////////////
    /////  PR1 EX2 TEST 4  //////
    /////////////////////////////
    failed = false;
    start_test(test_section, "PR1_EX2_4", "Add a new campaign in the same city and date but other project code");
    if (fail_all) {
        failed = true;
    } else {
        csv_initEntry(&entry);
        csv_parseEntry(&entry,  "01/01/2023;MSF;Medecins Sans Frontieres;Barcelona;MSF0002;12500.00;5", "CAMPAIGN");
        error = api_addCampaign(&data, entry);
        if (error != E_SUCCESS) {
            failed = true;
            passed = false;
            fail_all = true;
        }
        csv_freeEntry(&entry);
    }
    end_test(test_section, "PR1_EX2_4", !failed);

    /////////////////////////////
    /////  PR1 EX2 TEST 5  //////
    /////////////////////////////
    failed = false;
    start_test(test_section, "PR1_EX2_5", "Add a new campaign AND INVALID_ENTRY_FORMAT ");
    if (fail_all) {
        failed = true;
    } else {
        csv_initEntry(&entry);
        csv_parseEntry(&entry,  "M001;MSF;Barcelona;150000.00;01/01/2023;12500.00;15;0;0;0;0", "CAMPAIGN");
        error = api_addCampaign(&data, entry);
        if (error != E_INVALID_ENTRY_FORMAT) {
            failed = true;
            passed = false;
            fail_all = true;
        }
        csv_freeEntry(&entry);
    }
    end_test(test_section, "PR1_EX2_5", !failed);

    /////////////////////////////
    /////  PR1 EX2 TEST 6  //////
    /////////////////////////////
    failed = false;
    start_test(test_section, "PR1_EX2_6", "Add a new campaign AND INVALID_ENTRY_TYPE ");
    if (fail_all) {
        failed = true;
    } else {
        csv_initEntry(&entry);
        csv_parseEntry(&entry,  "01/01/2023;MSF;M001;Barcelona;150000.00;12500.00;15;0;0;0;0", "CAMPAINGGNNG");
        error = api_addCampaign(&data, entry);
        if (error != E_INVALID_ENTRY_TYPE) {
            failed = true;
            passed = false;
            fail_all = true;
        }
        csv_freeEntry(&entry);
    }
    end_test(test_section, "PR1_EX2_6", !failed);


	/////////////////////////////
    /////  PR1 EX2 TEST 7  //////
    /////////////////////////////
    failed = false;
    start_test(test_section, "PR1_EX2_7", "Check the number of campaigns");
    if (fail_all) {
        failed = true;
    } else {
        nCampaigns = api_campaignCount(data);
        if (nCampaigns != 2) {
            failed = true;
            passed = false;
            fail_all = true;
        }
    }
    end_test(test_section, "PR1_EX2_7", !failed);

	/////////////////////////////
    /////  PR1 EX2 TEST 7  //////
    /////////////////////////////
    failed = false;
    start_test(test_section, "PR1_EX2_8", "Check the number of projects");
    if (fail_all) {
        failed = true;
    } else {
        nProjects = api_projectCount(data);
        if (nProjects != 2) {
            failed = true;
            passed = false;
            fail_all = true;
        }
    }
    end_test(test_section, "PR1_EX2_8", !failed);

    /////////////////////////////
    /////  PR1 EX2 TEST 9 //////
    /////////////////////////////
	
    failed = false;
    start_test(test_section, "PR1_EX2_9", "Free API data");
    if (fail_all) {
        failed = true;
    } else {
        error = api_freeData(&data);
        nCampaigns = api_campaignCount(data);
        nProjects = api_projectCount(data);
        if (error != E_SUCCESS || nCampaigns != 0 || nProjects != 0 ) {
            failed = true;
            passed = false;
            fail_all = true;
        }
    }
    end_test(test_section, "PR1_EX2_9", !failed);

    
    return passed;


}

// Run all tests for Exercice 3 of PR1
bool run_pr1_ex3(tTestSection* test_section, const char* input) {
    tApiData data;
    tApiError error;
    tCSVEntry entry;
    tCSVEntry refEntry;
    tCSVData report;
    tCSVData refReport;
    tDate date;
    int nProjects;
    int nCampaigns;

    bool passed = true;
    bool failed = false;
    bool fail_all = false;
    
    
    // Initialize the data    
    error = api_initData(&data);
    if (error != E_SUCCESS) {        
        passed = false;        
        fail_all = true;
    }
    
    if (!fail_all) {
        error = api_loadData(&data, input, true);
        nProjects = api_projectCount(data);
        nCampaigns= api_campaignCount(data);
        if (error != E_SUCCESS || nProjects != 5 || nCampaigns != 5 ) {            
            passed = false;
            fail_all = true;
        }
    }
    
    
    /////////////////////////////
    /////  PR1 EX3 TEST 1  //////
    /////////////////////////////
    failed = false;
    start_test(test_section, "PR1_EX3_1", "Request a valid project");
    if (fail_all) {
        failed = true;
    } else {        
        csv_initEntry(&entry);
        csv_initEntry(&refEntry);
        csv_parseEntry(&refEntry, "MSF0001;MSF", "PROJECT");
        error = api_getProject(data, "MSF0001", &entry);
        if (error != E_SUCCESS || !csv_equalsEntry(entry, refEntry)) {
            failed = true;
            passed = false;            
        }
        csv_freeEntry(&entry);
        csv_freeEntry(&refEntry);
    }
    end_test(test_section, "PR1_EX3_1", !failed);
    
    /////////////////////////////
    /////  PR1 EX3 TEST 2  //////
    /////////////////////////////
    failed = false;
    start_test(test_section, "PR1_EX3_2", "Request a missing project");
    if (fail_all) {
        failed = true;
    } else {
        csv_initEntry(&entry);
        error = api_getProject(data, "NO_PROJECT", &entry);
        if (error != E_PROJECT_NOT_FOUND) {
            failed = true;
            passed = false;            
        }
        csv_freeEntry(&entry);        
    }
    end_test(test_section, "PR1_EX3_2", !failed);
           
    /////////////////////////////
    /////  PR1 EX3 TEST 3  //////
    /////////////////////////////
    failed = false;
    start_test(test_section, "PR1_EX3_3", "Request a valid campaign");
    if (fail_all) {
        failed = true;
    } else {        
        csv_initEntry(&entry);
        csv_initEntry(&refEntry);
  
        csv_parseEntry(&refEntry, "CRE1005;20/01/2023;Olot;25000.00;25", "CAMPAIGN");
        date_parse(&date, "20/01/2023");

        error = api_getCampaign(data, "CRE1005", "Olot", date, &entry);
        if (error != E_SUCCESS || !csv_equalsEntry(entry, refEntry)) {
            failed = true;
            passed = false;            
        }
        csv_freeEntry(&entry);
        csv_freeEntry(&refEntry);
    }
    end_test(test_section, "PR1_EX3_3", !failed);
    
    /////////////////////////////
    /////  PR1 EX3 TEST 4  //////
    /////////////////////////////
    failed = false;
    start_test(test_section, "PR1_EX3_4", "Request a missing campaign");
    if (fail_all) {
        failed = true;
    } else {
        csv_initEntry(&entry);
        date_parse(&date, "20/01/2023");
        error = api_getCampaign(data, "C100", "XXXXXX", date, &entry);
        if (error != E_CAMPAIGN_NOT_FOUND) {
            failed = true;
            passed = false;            
        }        
        csv_freeEntry(&entry);
    }
    end_test(test_section, "PR1_EX3_4", !failed);
    
    /////////////////////////////
    /////  PR1 EX3 TEST 5  //////
    /////////////////////////////
    failed = false;
    start_test(test_section, "PR1_EX3_5", "Get registered projects");
    if (fail_all) {
        failed = true;
    } else {
        csv_init(&report);
        csv_init(&refReport);
        csv_addStrEntry(&refReport, "ACN0004;ACN", "PROJECT");
        csv_addStrEntry(&refReport, "CRE1005;CRE", "PROJECT");     
        csv_addStrEntry(&refReport, "CRE1010;CRE", "PROJECT");
        csv_addStrEntry(&refReport, "MSF0001;MSF", "PROJECT");
        csv_addStrEntry(&refReport, "MSF0100;MSF", "PROJECT");

        error = api_getProjects(data, &report);
        if (error != E_SUCCESS || !csv_equals(report, refReport)) {
            failed = true;
            passed = false;            
        }  
        csv_free(&report);
        csv_free(&refReport);
    }
    end_test(test_section, "PR1_EX3_5", !failed);
    
    /////////////////////////////
    /////  PR1 EX3 TEST 6  //////
    /////////////////////////////
    failed = false;
    start_test(test_section, "PR1_EX3_6", "Get registered campaigns");
    if (fail_all) {
        failed = true;
    } else {
        csv_init(&report);
        csv_init(&refReport);
                
        csv_addStrEntry(&refReport, "MSF0001;01/01/2023;Barcelona;12500.00;5", "CAMPAIGN");
        csv_addStrEntry(&refReport, "CRE1010;15/02/2023;Tortosa;50000.00;20", "CAMPAIGN");
        csv_addStrEntry(&refReport, "ACN0004;01/01/2023;Girona;65000.00;50", "CAMPAIGN");
        csv_addStrEntry(&refReport, "CRE1005;20/01/2023;Olot;25000.00;25", "CAMPAIGN");
        csv_addStrEntry(&refReport, "MSF0100;02/01/2023;Berga;27000.00;15", "CAMPAIGN");   

        error = api_getCampaigns(data, &report);
        if (error != E_SUCCESS || !csv_equals(report, refReport)) {
            failed = true;
            passed = false;            
        }  
        csv_free(&report);
        csv_free(&refReport);
    }
    end_test(test_section, "PR1_EX3_6", !failed);
    
    // Release all data
    api_freeData(&data);
    
    return passed;
}
