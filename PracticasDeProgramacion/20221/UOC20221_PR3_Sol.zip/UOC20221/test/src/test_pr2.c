#include <assert.h>
#include <stdlib.h>
#include <string.h>
#include "test_pr2.h"
#include "api.h"

// Run all tests for PR1
bool run_pr2(tTestSuite* test_suite, const char* input) { 
    bool ok = true;
    tTestSection* section = NULL;

    assert(test_suite != NULL);

    testSuite_addSection(test_suite, "PR2", "Tests for PR2 exercices");

    section = testSuite_getSection(test_suite, "PR2");
    assert(section != NULL);

    ok = run_pr2_ex1(section, input);
    ok = run_pr2_ex2(section, input) && ok;
    ok = run_pr2_ex3(section, input) && ok;

    return ok;
}

// Run all tests for Exercice 1 of PR2
bool run_pr2_ex1(tTestSection* test_section, const char* input) {   
    tApiData data;
    tApiError error;
    tDate date;
    tCampaignBudgetDataList campaignBudgetDataList;
	tCampaign* pCampaign1;
	tCampaign* pCampaign2;
//	tCampaign* pCampaign3;
	tProject* pProject1;
	tProject* pProject2;
    int nProjects;
    int nCampaigns;
	int campaignNodeCounts_01_01;
	int campaignNodeCounts_03_01;
	int campaignNodeCounts_05_01;
	float dailyCost_01_01=0.0;
	float dailyCost_03_01=0.0;
    float dailyCost_05_01=0.0;
	int campaignDailyCounts;

    bool passed = true;
    bool failed = false;
    bool fail_all = false;
    

        // Initialize the data    
    error = api_initData(&data);
    if (error != E_SUCCESS) {        
        passed = false;        
        fail_all = true;
    }

    if (!fail_all) {
        error = api_loadData(&data, input, true);
        nProjects = api_projectCount(data);
        nCampaigns= api_campaignCount(data);
        if (error != E_SUCCESS || nProjects != 5 || nCampaigns != 5 ) {            
            passed = false;
            fail_all = true;
        }
    }

 
    /////////////////////////////
    /////  PR2 EX1 TEST 1  //////
    /////////////////////////////    
    start_test(test_section, "PR2_EX1_1", "Initialize Campaign Budget Data structure");
    
    
    // Initialize the data    
    campaignBudgetDataList_init(&campaignBudgetDataList);
    if (campaignBudgetDataList.count != 0 || 
		campaignBudgetDataList.first != NULL || campaignBudgetDataList.last != NULL) {
        failed = true;
        passed = false;
        fail_all = true;
    }
    end_test(test_section, "PR2_EX1_1", !failed);
    
    /////////////////////////////
    /////  PR2 EX1 TEST 2  //////
    /////////////////////////////
    failed = fail_all;
    start_test(test_section, "PR2_EX1_2", "Load Data and Add new Campaign Budget Data - 02/01/23, MSF0001, and Berga");
    
		
    // Add the campaign NODE 
    date_parse(&date, "02/01/2023");
    pCampaign1 = campaignData_findCampaign(data.campaignData, "MSF0100", "Berga", date); 
    if (pCampaign1 == NULL) {
        failed = true;
        passed = false;
        fail_all = false;
	} else {
        date_parse(&date, "03/01/2023");
        error = campaignBudgetDataList_add(&campaignBudgetDataList, date, pCampaign1);

		campaignNodeCounts_03_01 = campaignBudgetDataList_campaignNodeCounts(&campaignBudgetDataList, date);
        campaignDailyCounts = campaignBudgetDataList_campaignDailyCounts(&campaignBudgetDataList);
        dailyCost_03_01 = campaignBudgetDataList_getDailyCost(&campaignBudgetDataList, date);
		pProject1 = projectList_find(data.projects, "MSF0100");

	
        if (!(error == E_SUCCESS && campaignDailyCounts==1 && 
		  campaignNodeCounts_03_01 == 1 && 
          pProject1->budget == (750000 - pCampaign1->cost) &&
          dailyCost_03_01 == pCampaign1->cost)) {
			failed = true;
			passed = false;
			fail_all = false;
		}
	 
	} 
    end_test(test_section, "PR2_EX1_2", !failed);

    /////////////////////////////
    /////  PR2 EX1 TEST 3  //////
    /////////////////////////////
    failed = fail_all;
    start_test(test_section, "PR2_EX1_3", "Add a second Campaign Budget Data - 03/01/23, MSF0001, and Barcelona");
    
		
    // Add the campaign NODE 
     date_parse(&date, "01/01/2023");
     pCampaign2 = campaignData_findCampaign(data.campaignData, "MSF0001", "Barcelona", date); 
     if (pCampaign2 == NULL) {
		failed = true;
        passed = false;
        fail_all = false;
	 } 
	 else {
        date_parse(&date, "03/01/2023");
        error = campaignBudgetDataList_add(&campaignBudgetDataList, date, pCampaign2);

		campaignNodeCounts_03_01 = campaignBudgetDataList_campaignNodeCounts(&campaignBudgetDataList, date);
        campaignDailyCounts = campaignBudgetDataList_campaignDailyCounts(&campaignBudgetDataList);
        dailyCost_03_01 = campaignBudgetDataList_getDailyCost(&campaignBudgetDataList, date);
	
		pProject2 = projectList_find(data.projects, "MSF0001");

	// Project MSF0001 // budget = 150k
	// Project MSF0100 // budget = 750k
	if (!(error == E_SUCCESS && campaignDailyCounts==1 && 
		  campaignNodeCounts_03_01 == 2 && 
		  pProject1->budget == (750000 - pCampaign1->cost) &&
          pProject2->budget == (150000 - pCampaign2->cost) &&
          dailyCost_03_01 == (pCampaign1->cost+pCampaign2->cost))) {
			failed = true;
			passed = false;
			fail_all = false;
		}
	 
	 } 
    end_test(test_section, "PR2_EX1_3", !failed);

    /////////////////////////////
    /////  PR2 EX1 TEST 4  //////
    /////////////////////////////
    failed = fail_all;
    start_test(test_section, "PR2_EX1_4", "Add a DUPLICATED Campaign Budget Data - 02/01/23, MSF0001, and Barcelona");
    
		
        // Add the campaign NODE 
     date_parse(&date, "01/01/2023");
     pCampaign2 = campaignData_findCampaign(data.campaignData, "MSF0001", "Barcelona", date); 
     if (pCampaign2 == NULL) {
		failed = true;
        passed = false;
        fail_all = false;
	 } 
	 else {
        date_parse(&date, "03/01/2023");
        error = campaignBudgetDataList_add(&campaignBudgetDataList, date, pCampaign2);

		if (error != E_DUPLICATED) {
				failed = true;
				passed = false;
				fail_all = false;
		}
	 
	} 
    end_test(test_section, "PR2_EX1_4", !failed);

    /////////////////////////////
    /////  PR2 EX1 TEST 5  //////
    /////////////////////////////
    failed = fail_all;
    start_test(test_section, "PR2_EX1_5", "Add a Campaign Budget Data - 05/01/23, MSF0100, and Berga");
    
     // Add the campaign NODE 
     date_parse(&date, "02/01/2023");
     pCampaign1 = campaignData_findCampaign(data.campaignData, "MSF0100", "Berga", date); 
     if (pCampaign1 == NULL) {
		failed = true;
        passed = false;
        fail_all = false;
	 } 
	 else {
        date_parse(&date, "05/01/2023");
        error = campaignBudgetDataList_add(&campaignBudgetDataList, date, pCampaign1);

        date_parse(&date, "03/01/2023");
		campaignNodeCounts_03_01 = campaignBudgetDataList_campaignNodeCounts(&campaignBudgetDataList, date);
        dailyCost_03_01 = campaignBudgetDataList_getDailyCost(&campaignBudgetDataList, date);
        
        date_parse(&date, "05/01/2023");
		campaignNodeCounts_05_01 = campaignBudgetDataList_campaignNodeCounts(&campaignBudgetDataList, date);
        campaignDailyCounts = campaignBudgetDataList_campaignDailyCounts(&campaignBudgetDataList);
        dailyCost_05_01 = campaignBudgetDataList_getDailyCost(&campaignBudgetDataList, date);
	
		pProject2 = projectList_find(data.projects, "MSF0001");

	// Project MSF0001 // budget = 150k
	// Project MSF0100 // budget = 750k
	if (!(error == E_SUCCESS && campaignDailyCounts==3 && 
		  campaignNodeCounts_03_01 == 2 && 
		  campaignNodeCounts_05_01 == 1 &&
		  pProject1->budget == (750000 - pCampaign1->cost - pCampaign1->cost) &&
          pProject2->budget == (150000 - pCampaign2->cost) &&
          dailyCost_03_01 == pCampaign1->cost+pCampaign2->cost &&
          dailyCost_05_01 == pCampaign1->cost)) {
			failed = true;
			passed = false;
			fail_all = false;
		}
	 
	 } 
    end_test(test_section, "PR2_EX1_5", !failed);

    /////////////////////////////
    /////  PR2 EX1 TEST 6  //////
    /////////////////////////////
    failed = fail_all;
    start_test(test_section, "PR2_EX1_6", "Add a Campaign Budget Data - 01/01/23, MSF0001, and Barelona");
    
		
        // Add the campaign NODE 
     date_parse(&date, "01/01/2023");
     pCampaign2 = campaignData_findCampaign(data.campaignData, "MSF0001", "Barcelona", date); 
     if (pCampaign2 == NULL) {
		failed = true;
        passed = false;
        fail_all = false;
	 } 
	 else {
        date_parse(&date, "01/01/2023");
        error = campaignBudgetDataList_add(&campaignBudgetDataList, date, pCampaign1);

        date_parse(&date, "01/01/2023");
		campaignNodeCounts_01_01 = campaignBudgetDataList_campaignNodeCounts(&campaignBudgetDataList, date);
        dailyCost_01_01 = campaignBudgetDataList_getDailyCost(&campaignBudgetDataList, date);
        campaignDailyCounts = campaignBudgetDataList_campaignDailyCounts(&campaignBudgetDataList);
		pProject2 = projectList_find(data.projects, "MSF0001");

	// Project MSF0001 // budget = 150k
	// Project MSF0100 // budget = 750k
	if (!(error == E_SUCCESS && campaignDailyCounts==5 && 
          campaignNodeCounts_01_01 == 1 &&
		  campaignNodeCounts_03_01 == 2 && 
		  campaignNodeCounts_05_01 == 1 &&
		  pProject1->budget == (750000 - pCampaign1->cost - pCampaign1->cost - pCampaign1->cost) &&
          pProject2->budget == (150000 - pCampaign2->cost) &&
          dailyCost_01_01 == pCampaign1->cost &&
          dailyCost_03_01 == pCampaign1->cost+pCampaign2->cost &&
          dailyCost_05_01 == pCampaign1->cost)) {
			failed = true;
			passed = false;
			fail_all = false;
		}
	 
	 } 
    end_test(test_section, "PR2_EX1_6", !failed);
 
    // Release used memory
    api_freeData(&data);
    campaignBudgetDataList_free(&campaignBudgetDataList);

    return passed;
}


// Run all tests for Exercice 2 of PR2
bool run_pr2_ex2(tTestSection* test_section, const char* input) {    

 //   tProject pFoo;
    tONGList list;    
    tONG ngo;
    tONG *pONG;
    tProject fooProject;
    
    bool passed = true;
    bool failed = false;
    bool fail_all = false;
   
    /////////////////////////////
    /////  PR2 EX2 TEST 1  //////
    /////////////////////////////    
    start_test(test_section, "PR2_EX2_1", "Initialize a NGO");
    
    // Set incorrect value
    ngo.projects.count = -77;

    
    // Initialize the data    
    ong_init(&ngo, "NGO00", "Foo ONG");
    if (ngo.projects.count != 0 || strcmp(ngo.name, "Foo ONG") != 0 || strcmp(ngo.code, "NGO00") != 0 ) {
        failed = true;
        passed = false;
        fail_all = true;
    }
    end_test(test_section, "PR2_EX2_1", !failed);
    
    
    /////////////////////////////
    /////  PR2 EX2 TEST 2  //////
    /////////////////////////////
    failed = fail_all;
    start_test(test_section, "PR2_EX2_2", "Remove NGO data");
    
    if (!fail_all) {
        // Add 
        project_init(&fooProject,"P01","0001",1000.0);
        projectList_insert(&ngo.projects, fooProject);
      
        
        // Clean center data
        ong_free(&ngo);
        if (ngo.code != NULL) {
            failed = true;
        } else if (ngo.projects.count != 0) {
            failed = true;
        } else if (ngo.projects.first != NULL) {
            failed = true;
        } else if (ngo.staff.count != 0) {
            failed = true;
        }else if (ngo.staff.elems != NULL) {
            failed = true;
        } else if (ngo.name != NULL) {
            failed = true;
        } else if (ngo.code != NULL) {
            failed = true;
        }

        if (failed) {
            fail_all = true;
            passed = false;
        } 

        project_free(&fooProject);
    } 
    end_test(test_section, "PR2_EX2_2", !failed);
    
    /////////////////////////////
    /////  PR2 EX2 TEST 3  //////
    /////////////////////////////
    failed = fail_all;
    start_test(test_section, "PR2_EX2_3", "Initialize list of NGOs");
    
    if (!fail_all) {
        // Set incorrect value
        list.count = -34;
    
        // Initialize the data    
        ongList_init(&list);
        if (list.count != 0 || list.first != NULL) {
            failed = true;
            passed = false;
            fail_all = true;
        }        
    } 
    end_test(test_section, "PR2_EX2_3", !failed);
    
    /////////////////////////////
    /////  PR2 EX2 TEST 4  //////
    /////////////////////////////
    failed = fail_all;
    start_test(test_section, "PR2_EX2_4", "Insert a NGO to an empty list");
    
    if (!fail_all) {       
    
        // Initialize the data    
        ongList_init(&list);
       
        // Insert a new center
        ongList_insert(&list, "0004","FOO ONG");               
        if (list.count != 1 || list.first == NULL || 
            strcmp(list.first->elem.code, "0004") != 0 || 
            strcmp(list.first->elem.name, "FOO ONG") != 0)  {
            failed = true;
            passed = false;
            fail_all = true;
        }        
    } 
    end_test(test_section, "PR2_EX2_4", !failed);
    
    /////////////////////////////
    /////  PR2 EX2 TEST 5  //////
    /////////////////////////////
    failed = fail_all;
    start_test(test_section, "PR2_EX2_5", "Test Code sorting");
    
    if (!fail_all) {       
        // Insert a new center
        ongList_insert(&list, "0005","BAR ONG");         
       
        if (list.count != 2 || list.first == NULL || strcmp(list.first->elem.code, "0004") != 0) {
            failed = true;
            passed = false;
            fail_all = true;
        } else if (list.first->next == NULL || strcmp(list.first->next->elem.code, "0005") != 0) {
            failed = true;
            passed = false;
            fail_all = true;
        }       
        
        // Insert a new center
        ongList_insert(&list, "0001","OTHER ONG");        
        
        if (list.count != 3 || list.first == NULL || strcmp(list.first->elem.code, "0001") != 0) {
            failed = true;
            passed = false;
            fail_all = true;
        } else if (list.first->next == NULL || strcmp(list.first->next->elem.code, "0004") != 0) {
            failed = true;
            passed = false;
            fail_all = true;
        } else if (list.first->next->next == NULL || strcmp(list.first->next->next->elem.code, "0005") != 0) {
            failed = true;
            passed = false;
            fail_all = true;
        }       
    } 
    end_test(test_section, "PR2_EX2_5", !failed);
    
    /////////////////////////////
    /////  PR2 EX2 TEST 6  //////
    /////////////////////////////
    failed = fail_all;
    start_test(test_section, "PR2_EX2_6", "Find an existing ONG Code");
    
    if (!fail_all) {
        
        // Initialize the data    
        pONG = ongList_find(&list, "0001");
        if (pONG == NULL || strcmp(pONG->code, "0001") != 0) {
            failed = true;
            passed = false;
            fail_all = true;
        }        
    } 
    end_test(test_section, "PR2_EX2_6", !failed);
    
    /////////////////////////////
    /////  PR2 EX2 TEST 7  //////
    /////////////////////////////
    failed = fail_all;
    start_test(test_section, "PR2_EX2_7", "Find a non existing ONG by Code");
    
    if (!fail_all) {
        
        // Initialize the data    
        pONG = ongList_find(&list, "0006");
        if (pONG != NULL) {
            failed = true;
            passed = false;
            fail_all = true;
        }        
    } 
    end_test(test_section, "PR2_EX2_7", !failed);
    
    /////////////////////////////
    /////  PR2 EX2 TEST 8  //////
    /////////////////////////////
    failed = fail_all;
    start_test(test_section, "PR2_EX2_8", "Release a list of NGOs");
    
    if (!fail_all) {
        
        // Initialize the data    
        ongList_free(&list);
        if (list.count != 0 || list.first != NULL) {
            failed = true;
            passed = false;
            fail_all = true;
        }        
    } 
    end_test(test_section, "PR2_EX2_8", !failed);
    
    return passed;
}


// Run all tests for Exercice 3 of PR2
bool run_pr2_ex3(tTestSection* test_section, const char* input) {    
    tApiData data;
    tApiError error;    
    bool passed = true;
    bool failed = false;
    bool fail_all = false;
    int nStaff;
    int nProjects;
    int nCampaigns;
    int nONG;   
    
    /////////////////////////////
    /////  PR2 EX3 TEST 1  //////
    /////////////////////////////
    failed = false;
    start_test(test_section, "PR2_EX3_1", "Initialize the API data");
    // Initialize the data    
    error = E_SUCCESS; 
    api_initData(&data);
    if (error != E_SUCCESS) {        
        passed = false; 
        failed = true;
        fail_all = true;
    } else if (api_ongCount(data) != 0) {
        passed = false; 
        failed = true;
        fail_all = true;
    }      
	
    end_test(test_section, "PR2_EX3_1", !failed);
    
    
    /////////////////////////////
    /////  PR2 EX3 TEST 2  //////
    /////////////////////////////
    failed = fail_all;
        
    error = api_loadData(&data, input, true);
        
    start_test(test_section, "PR2_EX3_2", "Load API data");
    if (!fail_all) {
        error = api_loadData(&data, input, true);
        nStaff = api_staffCount(data);
        nProjects = api_projectCount(data);
        nCampaigns = api_campaignCount(data);        
 
        if (error != E_SUCCESS || nStaff != 4 || nProjects != 5 || nCampaigns != 5) {            
            passed = false; 
            failed = true;
            fail_all = true;
        }
    }
    end_test(test_section, "PR2_EX3_2", !failed);
     
    
    /////////////////////////////
    /////  PR2 EX3 TEST 3  //////
    /////////////////////////////
    failed = fail_all;
    start_test(test_section, "PR2_EX3_3", "Obtain number of NGOs in the API");
    if (!fail_all) {
        nONG = api_ongCount(data);
        if (nONG != 3) {            
            passed = false; 
            failed = true;
            fail_all = true;
        }
    }
    end_test(test_section, "PR2_EX3_3", !failed);
    
    /////////////////////////////
    /////  PR2 EX3 TEST 4  //////
    /////////////////////////////
    
    // Release all data
    api_freeData(&data);
    
    failed = fail_all;
    start_test(test_section, "PR2_EX3_4", "Remove all data");
    if (!fail_all) {
        nStaff = api_staffCount(data);
        nProjects = api_projectCount(data);
        nCampaigns = api_campaignCount(data);  
        nONG = api_ongCount(data);      
 
        if (error != E_SUCCESS || nStaff != 0 || nProjects != 0 || nCampaigns != 0 || nONG != 0) {            
            passed = false; 
            failed = true;
            fail_all = true;
        }
    }
    end_test(test_section, "PR2_EX3_4", !failed);
        
    
    
    return passed;
}
