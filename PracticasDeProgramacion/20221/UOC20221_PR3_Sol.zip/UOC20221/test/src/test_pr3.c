#include <assert.h>
#include <stdlib.h>
#include <string.h>
#include "test_pr3.h"
#include "availability.h"
#include "api.h"

// Run all tests for PR1
bool run_pr3(tTestSuite* test_suite, const char* input) {
    bool ok = true;
    tTestSection* section = NULL;

    assert(test_suite != NULL);

    testSuite_addSection(test_suite, "PR3", "Tests for PR3 exercices");

    section = testSuite_getSection(test_suite, "PR3");
    assert(section != NULL);

    ok = run_pr3_ex1(section, input);
    ok = run_pr3_ex2(section, input) && ok;
    ok = run_pr3_ex3(section, input) && ok;

    return ok;
}

// Run all tests for Exercice 1 of PR3
bool run_pr3_ex1(tTestSection* test_section, const char* input) {
    tApiData data;
    tApiError error;            
    //tCSVEntry entry;
    tAvailabilityData availabilityData;

    tPerson* pPersonKrunal;
    tPerson* pPersonPep;
    tPerson* pPersonJesus;
    tPerson* pPersonJane;
    tPerson* pPersonLaura;

    tDate date;
    tDate dateStart;
    tDate dateEnd;
    int nProjects;
    int nCampaigns;
    int nNGOs;
    int nStaff;
    tState state;
    int pos = 0;
    
    /////////////////////////////
    /////  PR3 EX1 TEST 1  //////
    /////////////////////////////    
    start_test(test_section, "PR3_EX1_1", "Load Data and insert availability data");
    // Initialize the data    
    test_state_init(&state);
    error = api_initData(&data);
    assertIntEquals(test_section, "PR3_EX1_1", "error", E_SUCCESS, error, &state);

    if (!state.fail_all) {
      error = api_loadData(&data, input, true);
      assertIntEquals(test_section, "PR3_EX1_1", "error", E_SUCCESS, error, &state);
    }

    nProjects = api_projectCount(data);
    nCampaigns= api_campaignCount(data);
    nStaff = api_staffCount(data);
    nNGOs = api_ongCount(data);

    assertIntEquals(test_section, "PR3_EX1_1", "nProjects", 5, nProjects, &state);
    assertIntEquals(test_section, "PR3_EX1_1", "nCampaigns", 5, nCampaigns, &state);
    assertIntEquals(test_section, "PR3_EX1_1", "nNGOs", 3, nNGOs, &state);
    assertIntEquals(test_section, "PR3_EX1_1", "nStaff", 6, nStaff, &state);

    availabilityData_init(&availabilityData);

    assertIntEquals(test_section, "PR3_EX1_1", "availability.count", 0, availabilityData.count, &state);
    assertIsNULL(test_section, "PR3_EX1_1", "availabilityData.elems", availabilityData.elems, &state);

    pPersonPep = staff_findPerson(data.staff, "87621123B");
    assertIsNotNULL(test_section, "PR3_EX1_1", "pPerson", pPersonPep, &state);
    assertStrEquals(test_section, "PR3_EX1_1", "pPerson.name", "Pep", pPersonPep->name, &state);

    date_parse(&date, "05/01/2023");
    pos = availabilityData_insert(&availabilityData, pPersonPep,  date);    
    assertIntNotEquals(test_section, "PR3_EX1_1", "availability.pos", -1, pos, &state);
    
    if (!state.failed) {
        assertIntEquals(test_section, "PR3_EX1_1", "availability.count", 1, availabilityData.count, &state);
        assertEquals(test_section, "PR3_EX1_1", "availability.elems[0]", pPersonPep,  availabilityData.elems[pos].person, &state);
        
        assertDateEquals(test_section, "PR3_EX1_1", "avail(Pep).date.start", &date, 
            &(availabilityData.elems[pos].start), &state);

        assertDateEquals(test_section, "PR3_EX1_1", "avail(Pep).date.end", &date, 
            &(availabilityData.elems[pos].end), &state);
    }
    
    end_test(test_section, "PR3_EX1_1", !state.failed);


    /////////////////////////////
    /////  PR3 EX1 TEST 2 //////
    /////////////////////////////    
    start_test(test_section, "PR3_EX1_2", "Insert availability data - II");
    if (state.fail_all) {
		state.failed = true;		
	}
	else {
        pPersonKrunal = staff_findPerson(data.staff, "98232222A");
        assertIsNotNULL(test_section, "PR3_EX1_2", "pPerson", pPersonKrunal, &state);
        assertStrEquals(test_section, "PR3_EX1_2", "pPerson.name", "Krunal", pPersonKrunal->name, &state);


        pPersonJesus = staff_findPerson(data.staff, "87333163B");
        assertIsNotNULL(test_section, "PR3_EX1_2", "pPerson", pPersonJesus, &state);
        assertStrEquals(test_section, "PR3_EX1_2", "pPerson.name", "Jesus", pPersonJesus->name, &state);

        pPersonJane = staff_findPerson(data.staff, "98765432J");
        assertIsNotNULL(test_section, "PR3_EX1_2", "pPerson", pPersonJane, &state);
        assertStrEquals(test_section, "PR3_EX1_2", "pPerson.name", "Jane", pPersonJane->name, &state);

        pPersonLaura = staff_findPerson(data.staff, "98231252A");
        assertIsNotNULL(test_section, "PR3_EX1_2", "pPerson", pPersonLaura, &state);
        assertStrEquals(test_section, "PR3_EX1_2", "pPerson.name", "Laura", pPersonLaura->name, &state);

        date_parse(&date, "07/01/2023");
        pos = availabilityData_insert(&availabilityData, pPersonKrunal,  date);
        assertIntNotEquals(test_section, "PR3_EX1_2", "availability.pos", -1, pos, &state);
        assertIntEquals(test_section, "PR3_EX1_2", "availability.count", 2, availabilityData.count, &state);

        date_parse(&date, "03/01/2023");
        pos = availabilityData_insert(&availabilityData, pPersonJesus,  date);    
        assertIntNotEquals(test_section, "PR3_EX1_2", "availability.pos", -1, pos, &state);
        assertIntEquals(test_section, "PR3_EX1_2", "availability.count", 3, availabilityData.count, &state);

        date_parse(&date, "08/01/2023");
        pos = availabilityData_insert(&availabilityData, pPersonJane,  date);    
        assertIntNotEquals(test_section, "PR3_EX1_2", "availability.pos", -1, pos, &state);
        assertIntEquals(test_section, "PR3_EX1_2", "availability.count", 4, availabilityData.count, &state);

		if (!state.failed) {
			assertEquals(test_section, "PR3_EX1_2", "availability.elems[0]", pPersonJesus,  availabilityData.elems[0].person, &state);
			assertEquals(test_section, "PR3_EX1_2", "availability.elems[1]", pPersonPep,  availabilityData.elems[1].person, &state);
			assertEquals(test_section, "PR3_EX1_2", "availability.elems[2]", pPersonKrunal,  availabilityData.elems[2].person, &state);
			assertEquals(test_section, "PR3_EX1_2", "availability.elems[3]", pPersonJane,  availabilityData.elems[3].person, &state);
		}
	}
    end_test(test_section, "PR3_EX1_2", !state.failed);

    /////////////////////////////
    /////  PR3 EX1 TEST 3  //////
    /////////////////////////////    
    start_test(test_section, "PR3_EX1_3", "Insert availability data - 04/1 - 08/1");
    if (state.fail_all) {
		state.failed = true;		
	}
	else {
        date_parse(&date, "06/01/2023");
        pos = availabilityData_insert(&availabilityData, pPersonPep,  date);    
        assertIntEquals(test_section, "PR3_EX1_3", "availability.count", 4, availabilityData.count, &state);

        date_parse(&dateStart, "05/01/2023");
        date_parse(&dateEnd, "06/01/2023");
        
        assertDateEquals(test_section, "PR3_EX1_3", "avail(Pep).date.start", &dateStart, 
            &(availabilityData.elems[pos].start), &state);

        assertDateEquals(test_section, "PR3_EX1_3", "avail(Pep).date.end", &dateEnd, 
            &(availabilityData.elems[pos].end), &state);


        date_parse(&date, "07/01/2023");
        pos = availabilityData_insert(&availabilityData, pPersonPep,  date);    
        assertIntEquals(test_section, "PR3_EX1_3", "availability.count", 4, availabilityData.count, &state);

        date_parse(&dateStart, "05/01/2023");
        date_parse(&dateEnd, "07/01/2023");

        assertDateEquals(test_section, "PR3_EX1_3", "avail(Pep).date.start", &dateStart, 
            &(availabilityData.elems[pos].start), &state);

        assertDateEquals(test_section, "PR3_EX1_3", "avail(Pep).date.end", &dateEnd, 
            &(availabilityData.elems[pos].end), &state);

        date_parse(&date, "08/01/2023");
        pos = availabilityData_insert(&availabilityData, pPersonPep,  date);    
        assertIntNotEquals(test_section, "PR3_EX1_3", "pos", -1, pos, &state);
        assertIntEquals(test_section, "PR3_EX1_3", "availability.count", 4, availabilityData.count, &state);

        date_parse(&dateStart, "05/01/2023");
        date_parse(&dateEnd, "08/01/2023");

        if (!state.failed) {

            assertDateEquals(test_section, "PR3_EX1_3", "avail(Pep).date.start", &dateStart, 
                &(availabilityData.elems[pos].start), &state);

            assertDateEquals(test_section, "PR3_EX1_3", "avail(Pep).date.end", &dateEnd, 
                &(availabilityData.elems[pos].end), &state);

        }

        date_parse(&date, "04/01/2023");
        pos = availabilityData_insert(&availabilityData, pPersonPep,  date);    
        assertIntNotEquals(test_section, "PR3_EX1_3", "pos", -1, pos, &state);

		if (!state.failed) {
			date_parse(&dateStart, "04/01/2023");
			date_parse(&dateEnd, "08/01/2023");

			assertDateEquals(test_section, "PR3_EX1_3", "avail(Pep).date.start", &dateStart, 
				&(availabilityData.elems[pos].start), &state);

			assertDateEquals(test_section, "PR3_EX1_3", "avail(Pep).date.end", &dateEnd, 
				&(availabilityData.elems[pos].end), &state);


			assertIntEquals(test_section, "PR3_EX1_3", "availability.count", 4, availabilityData.count, &state);
			assertEquals(test_section, "PR3_EX1_3", "availability.elems[0]", pPersonJesus,  availabilityData.elems[0].person, &state);
			assertEquals(test_section, "PR3_EX1_3", "availability.elems[1]", pPersonPep,  availabilityData.elems[1].person, &state);
			assertEquals(test_section, "PR3_EX1_3", "availability.elems[2]", pPersonKrunal,  availabilityData.elems[2].person, &state);
			assertEquals(test_section, "PR3_EX1_3", "availability.elems[3]", pPersonJane,  availabilityData.elems[3].person, &state);
					
		}
	}
    end_test(test_section, "PR3_EX1_3", !state.failed);

    /////////////////////////////
    /////  PR3 EX1 TEST 4  //////
    /////////////////////////////    
    start_test(test_section, "PR3_EX1_4", "Insert availability data - 3/1 - 8/1");
	if (state.fail_all) {
		state.failed = true;		
	}
	else {
        date_parse(&date, "03/01/2023");
        pos = availabilityData_insert(&availabilityData, pPersonPep,  date); 
        assertIntNotEquals(test_section, "PR3_EX1_4", "pos", -1, pos, &state);
        
		if (!state.failed) {
			date_parse(&dateStart, "03/01/2023");
			date_parse(&dateEnd, "08/01/2023");
			
			assertDateEquals(test_section, "PR3_EX1_4", "avail(Pep).date.start", &dateStart, 
				&(availabilityData.elems[pos].start), &state);

			assertDateEquals(test_section, "PR3_EX1_4", "avail(Pep).date.end", &dateEnd, 
				&(availabilityData.elems[pos].end), &state);

			assertIntEquals(test_section, "PR3_EX1_4", "availability.count", 4, availabilityData.count, &state);
			assertEquals(test_section, "PR3_EX1_4", "availability.elems[0]", pPersonJesus,  availabilityData.elems[0].person, &state);
			assertEquals(test_section, "PR3_EX1_4", "availability.elems[1]", pPersonPep,  availabilityData.elems[1].person, &state);
			assertEquals(test_section, "PR3_EX1_4", "availability.elems[2]", pPersonKrunal,  availabilityData.elems[2].person, &state);
			assertEquals(test_section, "PR3_EX1_4", "availability.elems[3]", pPersonJane,  availabilityData.elems[3].person, &state);
		}
	}
    end_test(test_section, "PR3_EX1_4", !state.failed);

    /////////////////////////////
    /////  PR3 EX1 TEST 5  //////
    /////////////////////////////    
    start_test(test_section, "PR3_EX1_5", "Insert availability data - 2/1 - 8/1");
    if (state.fail_all) {
		state.failed = true;		
	}
	else {
        date_parse(&date, "02/01/2023");
        pos = availabilityData_insert(&availabilityData, pPersonPep,  date); 

        assertIntEquals(test_section, "PR3_EX1_5", "insert_pos", 0, pos, &state);

        assertIntEquals(test_section, "PR3_EX1_5", "availability.count", 4, availabilityData.count, &state);
        
        date_parse(&dateStart, "02/01/2023");
        date_parse(&dateEnd, "08/01/2023");
        
        if (!state.failed) {
            assertDateEquals(test_section, "PR3_EX1_5", "avail(Pep).date.start", &dateStart, 
                &(availabilityData.elems[pos].start), &state);

            assertDateEquals(test_section, "PR3_EX1_5", "avail(Pep).date.end", &dateEnd, 
                &(availabilityData.elems[pos].end), &state);

            assertIntEquals(test_section, "PR3_EX1_5", "availability.count", 4, availabilityData.count, &state);
            assertEquals(test_section, "PR3_EX1_5", "availability.elems[0]", pPersonPep,  availabilityData.elems[0].person, &state);
            assertEquals(test_section, "PR3_EX1_5", "availability.elems[1]", pPersonJesus,  availabilityData.elems[1].person, &state);
            assertEquals(test_section, "PR3_EX1_5", "availability.elems[2]", pPersonKrunal,  availabilityData.elems[2].person, &state);
            assertEquals(test_section, "PR3_EX1_5", "availability.elems[3]", pPersonJane,  availabilityData.elems[3].person, &state);
        }
    }
    end_test(test_section, "PR3_EX1_5", !state.failed);

    /////////////////////////////
    /////  PR3 EX1 TEST 6  //////
    /////////////////////////////    
    start_test(test_section, "PR3_EX1_6", "Insert availability data - 11/1");
    if (state.fail_all) {
		state.failed = true;		
	}
	else {
        date_parse(&date, "11/01/2023");
        pos = availabilityData_insert(&availabilityData, pPersonPep,  date);    
        assertIntEquals(test_section, "PR3_EX1_6", "insert_pos", 4, pos, &state);
        assertIntEquals(test_section, "PR3_EX1_6", "availability.count", 5, availabilityData.count, &state);
        
        if (!state.failed) {
			assertEquals(test_section, "PR3_EX1_6", "availability.elems[0]", pPersonPep,  availabilityData.elems[0].person, &state);
			assertEquals(test_section, "PR3_EX1_6", "availability.elems[1]", pPersonJesus,  availabilityData.elems[1].person, &state);
			assertEquals(test_section, "PR3_EX1_6", "availability.elems[2]", pPersonKrunal,  availabilityData.elems[2].person, &state);
			assertEquals(test_section, "PR3_EX1_6", "availability.elems[3]", pPersonJane,  availabilityData.elems[3].person, &state);
			assertEquals(test_section, "PR3_EX1_6", "availability.elems[4]", pPersonPep,  availabilityData.elems[4].person, &state);
			
			assertDateEquals(test_section, "PR3_EX1_6", "avail(Pep-2).date.start", &date, 
            &(availabilityData.elems[pos].start), &state);

            assertDateEquals(test_section, "PR3_EX1_6", "avail(Pep-2).date.end", &date, 
            &(availabilityData.elems[pos].end), &state);
        }
    }
    end_test(test_section, "PR3_EX1_6", !state.failed);

    /////////////////////////////
    /////  PR3 EX1 TEST 7  //////
    /////////////////////////////    
    start_test(test_section, "PR3_EX1_7", "Insert availability data - 10/1 - 13/1");
	if (state.fail_all) {
		state.failed = true;		
	}
	else {
        date_parse(&date, "12/01/2023");
        pos = availabilityData_insert(&availabilityData, pPersonPep,  date);    
        assertIntEquals(test_section, "PR3_EX1_7", "insert_pos", 4, pos, &state);
        assertIntEquals(test_section, "PR3_EX1_7", "availability.count", 5, availabilityData.count, &state);
        if (!state.failed) {
			assertEquals(test_section, "PR3_EX1_7", "availability.elems[0]", pPersonPep,  availabilityData.elems[0].person, &state);
			assertEquals(test_section, "PR3_EX1_7", "availability.elems[1]", pPersonJesus,  availabilityData.elems[1].person, &state);
			assertEquals(test_section, "PR3_EX1_7", "availability.elems[2]", pPersonKrunal,  availabilityData.elems[2].person, &state);
			assertEquals(test_section, "PR3_EX1_7", "availability.elems[3]", pPersonJane,  availabilityData.elems[3].person, &state);
			assertEquals(test_section, "PR3_EX1_7", "availability.elems[4]", pPersonPep,  availabilityData.elems[4].person, &state);

			date_parse(&dateStart, "11/01/2023");
			date_parse(&dateEnd, "12/01/2023");

			assertDateEquals(test_section, "PR3_EX1_7", "avail(Pep-2).date.start", &dateStart, 
				&(availabilityData.elems[pos].start), &state);

			assertDateEquals(test_section, "PR3_EX1_7", "avail(Pep-2).date.end", &dateEnd, 
				&(availabilityData.elems[pos].end), &state);

		}

        date_parse(&date, "13/01/2023");
        pos = availabilityData_insert(&availabilityData, pPersonPep,  date);    
        assertIntEquals(test_section, "PR3_EX1_7", "insert_pos", 4, pos, &state);
        assertIntEquals(test_section, "PR3_EX1_7", "availability.count", 5, availabilityData.count, &state);
        
        if (!state.failed) {
            assertEquals(test_section, "PR3_EX1_7", "availability.elems[0]", pPersonPep,  availabilityData.elems[0].person, &state);
            assertEquals(test_section, "PR3_EX1_7", "availability.elems[1]", pPersonJesus,  availabilityData.elems[1].person, &state);
            assertEquals(test_section, "PR3_EX1_7", "availability.elems[2]", pPersonKrunal,  availabilityData.elems[2].person, &state);
            assertEquals(test_section, "PR3_EX1_7", "availability.elems[3]", pPersonJane,  availabilityData.elems[3].person, &state);
            assertEquals(test_section, "PR3_EX1_7", "availability.elems[4]", pPersonPep,  availabilityData.elems[4].person, &state);

            date_parse(&dateStart, "11/01/2023");
            date_parse(&dateEnd, "13/01/2023");

            assertDateEquals(test_section, "PR3_EX1_7", "avail(Pep-2).date.start", &dateStart, 
                &(availabilityData.elems[pos].start), &state);

            assertDateEquals(test_section, "PR3_EX1_7", "avail(Pep-2).date.end", &dateEnd, 
                &(availabilityData.elems[pos].end), &state);

        }

        date_parse(&date, "10/01/2023");
        pos = availabilityData_insert(&availabilityData, pPersonPep,  date);    
        assertIntEquals(test_section, "PR3_EX1_7", "insert_pos", 4, pos, &state);
        assertIntEquals(test_section, "PR3_EX1_7", "availability.count", 5, availabilityData.count, &state);
       
       if (!state.failed) {
                assertEquals(test_section, "PR3_EX1_7", "availability.elems[0]", pPersonPep,  availabilityData.elems[0].person, &state);
            assertEquals(test_section, "PR3_EX1_7", "availability.elems[1]", pPersonJesus,  availabilityData.elems[1].person, &state);
            assertEquals(test_section, "PR3_EX1_7", "availability.elems[2]", pPersonKrunal,  availabilityData.elems[2].person, &state);
            assertEquals(test_section, "PR3_EX1_7", "availability.elems[3]", pPersonJane,  availabilityData.elems[3].person, &state);
            assertEquals(test_section, "PR3_EX1_7", "availability.elems[4]", pPersonPep,  availabilityData.elems[4].person, &state);

            date_parse(&dateStart, "10/01/2023");
            date_parse(&dateEnd, "13/01/2023");

            assertDateEquals(test_section, "PR3_EX1_7", "avail(Pep-2).date.start", &dateStart, 
                &(availabilityData.elems[pos].start), &state);

            assertDateEquals(test_section, "PR3_EX1_7", "avail(Pep-2).date.end", &dateEnd, 
                &(availabilityData.elems[pos].end), &state);

       }
    }
    end_test(test_section, "PR3_EX1_7", !state.failed);

    /////////////////////////////
    /////  PR3 EX1 TEST 8  //////
    /////////////////////////////    
    start_test(test_section, "PR3_EX1_8", "Insert availability data - 09/1 - MERGE");
    if (state.fail_all) {
		state.failed = true;		
	}
	else {
        date_parse(&date, "09/01/2023");
        pos = availabilityData_insert(&availabilityData, pPersonPep,  date);    
        assertIntEquals(test_section, "PR3_EX1_8", "insert_pos", 0, pos, &state);
        assertIntEquals(test_section, "PR3_EX1_8", "availability.count", 4, availabilityData.count, &state);
        
        if (!state.failed) {
            assertEquals(test_section, "PR3_EX1_8", "availability.elems[0]", pPersonPep,  availabilityData.elems[0].person, &state);
            assertEquals(test_section, "PR3_EX1_8", "availability.elems[1]", pPersonJesus,  availabilityData.elems[1].person, &state);
            assertEquals(test_section, "PR3_EX1_8", "availability.elems[2]", pPersonKrunal,  availabilityData.elems[2].person, &state);
            assertEquals(test_section, "PR3_EX1_8", "availability.elems[3]", pPersonJane,  availabilityData.elems[3].person, &state);
            
            date_parse(&dateStart, "02/01/2023");
            date_parse(&dateEnd, "13/01/2023");

            assertDateEquals(test_section, "PR3_EX1_8", "avail(Pep).date.start", &dateStart, 
                &(availabilityData.elems[pos].start), &state);

            assertDateEquals(test_section, "PR3_EX1_8", "avail(Pep).date.end", &dateEnd, 
                &(availabilityData.elems[pos].end), &state);
        }
    }
    end_test(test_section, "PR3_EX1_8", !state.failed);

    /////////////////////////////
    /////  PR3 EX1 TEST 9  //////
    /////////////////////////////    
    start_test(test_section, "PR3_EX1_9", "Insert availability data - 25/1");
    if (state.fail_all) {
		state.failed = true;		
	}
	else {
        date_parse(&date, "25/01/2023");
        pos = availabilityData_insert(&availabilityData, pPersonLaura,  date);    
        assertIntEquals(test_section, "PR3_EX1_9", "insert_pos", 4, pos, &state);
        assertIntEquals(test_section, "PR3_EX1_9", "availability.count", 5, availabilityData.count, &state);
        
        if (!state.failed) {
                assertEquals(test_section, "PR3_EX1_9", "availability.elems[0]", pPersonPep,  availabilityData.elems[0].person, &state);
                assertEquals(test_section, "PR3_EX1_9", "availability.elems[1]", pPersonJesus,  availabilityData.elems[1].person, &state);
                assertEquals(test_section, "PR3_EX1_9", "availability.elems[2]", pPersonKrunal,  availabilityData.elems[2].person, &state);
                assertEquals(test_section, "PR3_EX1_9", "availability.elems[3]", pPersonJane,  availabilityData.elems[3].person, &state);
                assertEquals(test_section, "PR3_EX1_9", "availability.elems[4]", pPersonLaura,  availabilityData.elems[4].person, &state);
                
                assertDateEquals(test_section, "PR3_EX1_9", "avail(Pep).date.start", &date, 
                    &(availabilityData.elems[pos].start), &state);

                assertDateEquals(test_section, "PR3_EX1_9", "avail(Pep).date.end", &date, 
                    &(availabilityData.elems[pos].end), &state);
        }
    }
    end_test(test_section, "PR3_EX1_9", !state.failed);


    /////////////////////////////
    /////  PR3 EX1 TEST 10 //////
    /////////////////////////////    
    start_test(test_section, "PR3_EX1_10", "remove availabilities");
    if (state.fail_all) {
		state.failed = true;		
	}
	else {

        assertIntEquals(test_section, "PR3_EX1_10", "availability.count", 5, availabilityData.count, &state);
        date_parse(&date, "25/01/2023");
        availabilityData_remove(&availabilityData, pPersonLaura, date);
        assertIntEquals(test_section, "PR3_EX1_10", "del 25/1, availability.count", 4, availabilityData.count, &state);
        
        if (!state.failed) {
            assertEquals(test_section, "PR3_EX1_10", "del 25/1, availability.elems[0]", pPersonPep,  availabilityData.elems[0].person, &state);
            assertEquals(test_section, "PR3_EX1_10", "del 25/1, availability.elems[1]", pPersonJesus,  availabilityData.elems[1].person, &state);
            assertEquals(test_section, "PR3_EX1_10", "del 25/1, availability.elems[2]", pPersonKrunal,  availabilityData.elems[2].person, &state);
            assertEquals(test_section, "PR3_EX1_10", "del 25/1, availability.elems[3]", pPersonJane,  availabilityData.elems[3].person, &state);
        }

        date_parse(&date, "13/01/2023");
        availabilityData_remove(&availabilityData, pPersonPep, date);
        assertIntEquals(test_section, "PR3_EX1_10", "del 13/1, availability.count", 4, availabilityData.count, &state);

        if (!state.failed) {
            assertEquals(test_section, "PR3_EX1_10", "del 13/1, availability.elems[0]", pPersonPep,  availabilityData.elems[0].person, &state);
            assertEquals(test_section, "PR3_EX1_10", "del 13/1, availability.elems[1]", pPersonJesus,  availabilityData.elems[1].person, &state);
            assertEquals(test_section, "PR3_EX1_10", "del 13/1, availability.elems[2]", pPersonKrunal,  availabilityData.elems[2].person, &state);
            assertEquals(test_section, "PR3_EX1_10", "del 13/1, availability.elems[3]", pPersonJane,  availabilityData.elems[3].person, &state);
            date_parse(&dateStart, "02/01/2023");
            date_parse(&dateEnd, "12/01/2023");

            assertDateEquals(test_section, "PR3_EX1_10", "avail(Pep).date.start", &dateStart, 
                &(availabilityData.elems[0].start), &state);

            assertDateEquals(test_section, "PR3_EX1_10", "avail(Pep).date.end", &dateEnd, 
                &(availabilityData.elems[0].end), &state);

        }

        date_parse(&date, "02/01/2023");
        availabilityData_remove(&availabilityData, pPersonPep, date);
        assertIntEquals(test_section, "PR3_EX1_10", "del 2/1, availability.count", 4, availabilityData.count, &state);

        if (!state.failed) {
            assertEquals(test_section, "PR3_EX1_10", "del 2/1, availability.elems[0]", pPersonPep,  availabilityData.elems[0].person, &state);
            assertEquals(test_section, "PR3_EX1_10", "del 2/1, availability.elems[1]", pPersonJesus,  availabilityData.elems[1].person, &state);
            assertEquals(test_section, "PR3_EX1_10", "del 2/1, availability.elems[2]", pPersonKrunal,  availabilityData.elems[2].person, &state);
            assertEquals(test_section, "PR3_EX1_10", "del 2/1, availability.elems[3]", pPersonJane,  availabilityData.elems[3].person, &state);

            date_parse(&dateStart, "03/01/2023");
            date_parse(&dateEnd, "12/01/2023");

            assertDateEquals(test_section, "PR3_EX1_10", "del 2/1, avail(Pep).date.start", &dateStart, 
                &(availabilityData.elems[0].start), &state);

            assertDateEquals(test_section, "PR3_EX1_10", "del 2/1, avail(Pep).date.end", &dateEnd, 
                &(availabilityData.elems[0].end), &state);
        }

        date_parse(&date, "03/01/2023");
        availabilityData_remove(&availabilityData, pPersonPep, date);
        assertIntEquals(test_section, "PR3_EX1_10", "del 3/1, availability.count", 4, availabilityData.count, &state);
        
        if (!state.failed) {
            assertEquals(test_section, "PR3_EX1_10", "del 3/1, availability.elems[0]", pPersonJesus,  availabilityData.elems[0].person, &state);
            assertEquals(test_section, "PR3_EX1_10", "del 3/1, availability.elems[1]", pPersonPep,  availabilityData.elems[1].person, &state);
            assertEquals(test_section, "PR3_EX1_10", "del 3/1, availability.elems[2]", pPersonKrunal,  availabilityData.elems[2].person, &state);
            assertEquals(test_section, "PR3_EX1_10", "del 3/1, availability.elems[3]", pPersonJane,  availabilityData.elems[3].person, &state);

            date_parse(&dateStart, "04/01/2023");
            date_parse(&dateEnd, "12/01/2023");
            assertDateEquals(test_section, "PR3_EX1_10", "avail(Pep).date.start", &dateStart, 
                &(availabilityData.elems[1].start), &state);

            assertDateEquals(test_section, "PR3_EX1_10", "avail(Pep).date.end", &dateEnd, 
                &(availabilityData.elems[1].end), &state);
        }


        date_parse(&date, "09/01/2023");
        availabilityData_remove(&availabilityData, pPersonPep, date);
        assertIntEquals(test_section, "PR3_EX1_10", "del 7/1 - SPLIT, availability.count", 5, availabilityData.count, &state);
        if (!state.failed) {
                assertEquals(test_section, "PR3_EX1_10", "del 7/1 - SPLIT, availability.elems[0]", pPersonJesus,  availabilityData.elems[0].person, &state);
                assertEquals(test_section, "PR3_EX1_10", "del 7/1 - SPLIT, availability.elems[1]", pPersonPep,  availabilityData.elems[1].person, &state);
                assertEquals(test_section, "PR3_EX1_10", "del 7/1 - SPLIT, availability.elems[2]", pPersonKrunal,  availabilityData.elems[2].person, &state);
                assertEquals(test_section, "PR3_EX1_10", "del 7/1 - SPLIT, availability.elems[3]", pPersonJane,  availabilityData.elems[3].person, &state);
                assertEquals(test_section, "PR3_EX1_10", "del 7/1 - SPLIT, availability.elems[4]", pPersonPep,  availabilityData.elems[4].person, &state);

                date_parse(&dateStart, "04/01/2023");
                date_parse(&dateEnd, "08/01/2023");

                assertDateEquals(test_section, "PR3_EX1_10", "del 7/1 - SPLIT, avail(Pep).date.start", &dateStart, 
                    &(availabilityData.elems[1].start), &state);

                assertDateEquals(test_section, "PR3_EX1_10", "del 7/1 - SPLIT, avail(Pep).date.end", &dateEnd, 
                    &(availabilityData.elems[1].end), &state);

                date_parse(&dateStart, "10/01/2023");
                date_parse(&dateEnd, "12/01/2023");

                assertDateEquals(test_section, "PR3_EX1_10", "del 7/1 - SPLIT, avail(Pep-2).date.start", &dateStart, 
                    &(availabilityData.elems[4].start), &state);

                assertDateEquals(test_section, "PR3_EX1_10", "del 7/1 - SPLIT, avail(Pep-2).date.end", &dateEnd, 
                    &(availabilityData.elems[4].end), &state);
        

        }
    }

    end_test(test_section, "PR3_EX1_10", !state.failed);


    /////////////////////////////
    /////  PR3 EX1 TEST 11  //////
    /////////////////////////////    
    start_test(test_section, "PR3_EX1_11", "Free availability data");
        if (state.fail_all) {
		state.failed = true;		
	}
	else {    
        availabilityData_free(&availabilityData);
        
        assertIntEquals(test_section, "PR3_EX1_11", "availability.count", 0, availabilityData.count, &state);
        assertIsNULL(test_section, "PR3_EX1_11", "availabilityData.elems", availabilityData.elems, &state);
    }
    end_test(test_section, "PR3_EX1_11", !state.failed);
    
    api_freeData(&data);

    return state.passed;
}


// Run all tests for Exercice 2 of PR3
bool run_pr3_ex2(tTestSection* test_section, const char* input) {                
    tApiData data;
    tApiError error;
    tDate date;
	tCSVData report;
	tCSVData refReport;

    int nProjects;
    int nCampaigns;
    int nNGOs;
    int nStaff;


    tState state;
    //int pos = 0;
    
    /////////////////////////////
    /////  PR3 EX2 TEST 1  //////
    /////////////////////////////    
    start_test(test_section, "PR3_EX2_1", "Load Data and init data");
    // Initialize the data    
    test_state_init(&state);
    if (state.fail_all) {
		state.failed = true;		
	}
	else {
		error = api_initData(&data);
		assertIntEquals(test_section, "PR3_EX2_1", "error", E_SUCCESS, error, &state);

	    error = api_loadData(&data, input, true);
	    assertIntEquals(test_section, "PR3_EX2_1", "error", E_SUCCESS, error, &state);
	
		nProjects = api_projectCount(data);
		nCampaigns= api_campaignCount(data);
		nStaff = api_staffCount(data);
		nNGOs = api_ongCount(data);

		assertIntEquals(test_section, "PR3_EX2_1", "nProjects", 5, nProjects, &state);
		assertIntEquals(test_section, "PR3_EX2_1", "nCampaigns", 5, nCampaigns, &state);
		assertIntEquals(test_section, "PR3_EX2_1", "nNGOs", 3, nNGOs, &state);
		assertIntEquals(test_section, "PR3_EX2_1", "nStaff", 6, nStaff, &state);	

		date_parse(&date, "05/01/2023");
		error = api_addAvailability(&data, "MSFXXXX", "87621123B", date);
		assertIntEquals(test_section, "PR3_EX2_1", "error", E_ONG_NOT_FOUND, error, &state);

		error = api_addAvailability(&data, "MSF", "XXXXXXX", date);
		assertIntEquals(test_section, "PR3_EX2_1", "error", E_PERSON_NOT_FOUND, error, &state);

		error = api_addAvailability(&data, "MSF", "87621123B", date);
		assertIntEquals(test_section, "PR3_EX2_1", "error", E_SUCCESS, error, &state);

		date_parse(&date, "06/01/2023");
		error = api_addAvailability(&data, "MSF", "87621123B", date);
		assertIntEquals(test_section, "PR3_EX2_1", "error", E_SUCCESS, error, &state);

		date_parse(&date, "07/01/2023");
		error = api_addAvailability(&data, "MSF", "87621123B", date);
		assertIntEquals(test_section, "PR3_EX2_1", "error", E_SUCCESS, error, &state);

		date_parse(&date, "06/01/2023");
		error = api_addAvailability(&data, "MSF", "98232222A", date);
		assertIntEquals(test_section, "PR3_EX2_1", "error", E_SUCCESS, error, &state);

		date_parse(&date, "06/01/2023");
		error = api_addAvailability(&data, "MSF", "98765432J", date);
		assertIntEquals(test_section, "PR3_EX2_1", "error", E_SUCCESS, error, &state);

		date_parse(&date, "12/01/2023");
		error = api_addAvailability(&data, "ACN", "87621123B", date);
		assertIntEquals(test_section, "PR3_EX2_1", "error", E_SUCCESS, error, &state);

		date_parse(&date, "16/01/2023");
		error = api_addAvailability(&data, "ACN", "87621123B", date);
		assertIntEquals(test_section, "PR3_EX2_1", "error", E_SUCCESS, error, &state);

		date_parse(&date, "20/01/2023");
		error = api_addAvailability(&data, "ACN", "87621123B", date);
		assertIntEquals(test_section, "PR3_EX2_1", "error", E_SUCCESS, error, &state);

		date_parse(&date, "21/01/2023");
		error = api_addAvailability(&data, "ACN", "87621123B", date);
		assertIntEquals(test_section, "PR3_EX2_1", "error", E_SUCCESS, error, &state);
	}
    end_test(test_section, "PR3_EX2_1", !state.failed);


    /////////////////////////////
    /////  PR3 EX2 TEST 2  //////
    /////////////////////////////    
    start_test(test_section, "PR3_EX2_2", "get Person Availability (Pep)");
    if (state.fail_all) {
		state.failed = true;		
	}
	else {
        error = api_getPersonAvailability(&data, "XXXXXXXX", &report);
        assertIntEquals(test_section, "PR3_EX2_2", "error", E_PERSON_NOT_FOUND, error, &state);


        csv_init(&report);
        csv_init(&refReport);
        csv_addStrEntry(&refReport, "12/01/2023;12/01/2023;ACN", "AVAILABILITY");
        csv_addStrEntry(&refReport, "16/01/2023;16/01/2023;ACN", "AVAILABILITY");

        csv_addStrEntry(&refReport, "20/01/2023;21/01/2023;ACN", "AVAILABILITY");
        csv_addStrEntry(&refReport, "05/01/2023;07/01/2023;MSF", "AVAILABILITY");
        
        error = api_getPersonAvailability(&data, "87621123B", &report);
        assertIntEquals(test_section, "PR3_EX2_2", "error", E_SUCCESS, error, &state);
        assertCsvEquals(test_section, "PR3_EX2_2", "cvs", refReport, report, &state);

		// Release all data
		csv_free(&report);
		csv_free(&refReport);
		api_freeData(&data);
    }
    end_test(test_section, "PR3_EX2_2", !state.failed);

    
    return state.passed; 
}


// Run all tests for Exercice 3 of PR3
bool run_pr3_ex3(tTestSection* test_section, const char* input) {   
      tApiData data;
    tApiError error;
    tCSVData report;
    tCSVData refReport;
    tDate date;

    int nProjects;
    int nCampaigns;
    int nNGOs;
    int nStaff;


    tState state;
    //int pos = 0;
    
    /////////////////////////////
    /////  PR3 EX3 TEST 1  //////
    /////////////////////////////    
    start_test(test_section, "PR3_EX3_1", "Load Data and init data");
    
    // Initialize the data    
    test_state_init(&state);
	if (state.fail_all) {
		state.failed = true;		
	}
	else {

        error = api_initData(&data);
        assertIntEquals(test_section, "PR3_EX3_1", "error", E_SUCCESS, error, &state);
		
		if (!state.failed) {
			error = api_loadData(&data, input, true);
			assertIntEquals(test_section, "PR3_EX3_1", "error", E_SUCCESS, error, &state);
		}

        assertIntEquals(test_section, "PR3_EX3_1", "error", E_SUCCESS, error, &state);
        nProjects = api_projectCount(data);
        nCampaigns= api_campaignCount(data);
        nStaff = api_staffCount(data);
        nNGOs = api_ongCount(data);

        assertIntEquals(test_section, "PR3_EX3_1", "nProjects", 5, nProjects, &state);
        assertIntEquals(test_section, "PR3_EX3_1", "nCampaigns", 5, nCampaigns, &state);
        assertIntEquals(test_section, "PR3_EX3_1", "nNGOs", 3, nNGOs, &state);
        assertIntEquals(test_section, "PR3_EX3_1", "nStaff", 6, nStaff, &state);

		date_parse(&date, "05/01/2023");
		error = api_addAvailability(&data, "MSFXXXX", "87621123B", date);
		assertIntEquals(test_section, "PR3_EX3_1", "error", E_ONG_NOT_FOUND, error, &state);

		error = api_addAvailability(&data, "MSF", "XXXXXXX", date);
		assertIntEquals(test_section, "PR3_EX3_1", "error", E_PERSON_NOT_FOUND, error, &state);

		error = api_addAvailability(&data, "MSF", "87621123B", date);
		assertIntEquals(test_section, "PR3_EX3_1", "error", E_SUCCESS, error, &state);

		date_parse(&date, "06/01/2023");
		error = api_addAvailability(&data, "MSF", "87621123B", date);
		assertIntEquals(test_section, "PR3_EX3_1", "error", E_SUCCESS, error, &state);

		date_parse(&date, "07/01/2023");
		error = api_addAvailability(&data, "MSF", "87621123B", date);
		assertIntEquals(test_section, "PR3_EX3_1", "error", E_SUCCESS, error, &state);

		date_parse(&date, "06/01/2023");
		error = api_addAvailability(&data, "MSF", "98232222A", date);
		assertIntEquals(test_section, "PR3_EX3_1", "error", E_SUCCESS, error, &state);

		date_parse(&date, "06/01/2023");
		error = api_addAvailability(&data, "MSF", "98765432J", date);
		assertIntEquals(test_section, "PR3_EX3_1", "error", E_SUCCESS, error, &state);

		date_parse(&date, "12/01/2023");
		error = api_addAvailability(&data, "ACN", "98765432J", date);
		assertIntEquals(test_section, "PR3_EX3_1", "error", E_SUCCESS, error, &state);

		date_parse(&date, "12/01/2023");
		error = api_addAvailability(&data, "ACN", "87333163B", date);
		assertIntEquals(test_section, "PR3_EX3_1", "error", E_SUCCESS, error, &state);

		date_parse(&date, "12/01/2023");
		error = api_addAvailability(&data, "ACN", "87621123B", date);
		assertIntEquals(test_section, "PR3_EX3_1", "error", E_SUCCESS, error, &state);

		date_parse(&date, "21/01/2023");
		error = api_addAvailability(&data, "ACN", "87621123B", date);
		date_parse(&date, "25/01/2023");
		error = api_addAvailability(&data, "ACN", "87621123B", date);

		date_parse(&date, "27/01/2023");
		error = api_addAvailability(&data, "ACN", "87621123B", date);
		date_parse(&date, "29/01/2023");
		error = api_addAvailability(&data, "ACN", "87621123B", date);

		assertIntEquals(test_section, "PR3_EX3_1", "error", E_SUCCESS, error, &state);

  }
  end_test(test_section, "PR3_EX3_1", !state.failed);

    /////////////////////////////
    /////  PR3 EX3 TEST 2  //////
    /////////////////////////////    
    start_test(test_section, "PR3_EX3_2", "Find staff available");
    if (state.fail_all) {
		state.failed = true;		
	}
	else {
        csv_init(&report);
        csv_init(&refReport);
        csv_addStrEntry(&refReport, "98765432J;Jane;Doe;jane.doe@example.com;Her street, 5;Barcelona;12/01/1995", "PERSON");
        csv_addStrEntry(&refReport, "87333163B;Jesus;Sallent;jesus.sallent@example.com;His street, 20;Barcelona;12/01/1968", "PERSON");
        csv_addStrEntry(&refReport, "87621123B;Pep;Botera;pepe.botera@example.com;His street, 20;Barcelona;12/01/1972", "PERSON");

        date_parse(&date, "12/01/2023");
        error = api_findStaffAvailable(&data, "ONG_XXX", date, &report);
        assertIntEquals(test_section, "PR3_EX3_2", "error", E_ONG_NOT_FOUND, error, &state);
        csv_free(&report);

        date_parse(&date, "12/01/2023");
        error = api_findStaffAvailable(&data, "ACN", date, &report);
        assertIntEquals(test_section, "PR3_EX3_2", "error", E_SUCCESS, error, &state);
        assertCsvEquals(test_section, "PR3_EX3_2", "cvs", refReport, report, &state);

        csv_free(&report);
        csv_free(&refReport);
    }

    end_test(test_section, "PR3_EX3_2", !state.failed);


    /////////////////////////////
    /////  PR3 EX3 TEST 3  //////
    /////////////////////////////    
    start_test(test_section, "PR3_EX3_3", "findCampaigns & setStaffCampaigns");
    if (state.fail_all) {
		state.failed = true;		
	}
	else {

        date_parse(&date, "12/01/2023");
        error = api_addCampaignDaily(&data, "MSF", "Berga", "MSF0100", date);
        assertIntEquals(test_section, "PR3_EX3_3", "error", E_SUCCESS, error, &state);

        date_parse(&date, "12/01/2023");
        error = api_addCampaignDaily(&data, "ACN", "Girona", "ACN0004", date);
        assertIntEquals(test_section, "PR3_EX3_3", "error", E_SUCCESS, error, &state);

        date_parse(&date, "02/02/2023");
        error = api_addCampaignDaily(&data, "CRE", "Olot", "CRE1005", date);
        assertIntEquals(test_section, "PR3_EX3_3", "error", E_SUCCESS, error, &state);

        csv_init(&report);
        csv_init(&refReport);

        csv_addStrEntry(&refReport, "12/01/2023;ACN;Girona;2", "CAMPAIGN");

        date_parse(&date, "12/01/2023");
        error = api_findCampaigns(&data, "ACN", date, &report);
        assertIntEquals(test_section, "PR3_EX3_3", "error", E_SUCCESS, error, &state);
        assertCsvEquals(test_section, "PR3_EX3_3", "cvs", refReport, report, &state);
        csv_free(&report);
        csv_free(&refReport);

        date_parse(&date, "12/01/2023");
        error = api_setStaffCampaigns(&data, "ONG_XXXXX", date);
        assertIntEquals(test_section, "PR3_EX3_3", "error", E_ONG_NOT_FOUND, error, &state);

        date_parse(&date, "12/01/2023");

        assertIsNULL(test_section, "PR3_EX3_3", "assigned staff", data.campaignData.elems[2].staff, &state);	
        
        date_parse(&date, "12/01/2023");        
        csv_init(&report);
        error = api_findStaffAvailable(&data, "ACN", date, &report);
        assertIntEquals(test_section, "PR3_EX3_3", "error", E_SUCCESS, error, &state);
        assertIntEquals(test_section, "PR3_EX3_3", "availibility(ACN)", 3, report.count, &state);
        csv_free(&report);
        
        error = api_setStaffCampaigns(&data, "ACN", date);
        assertIntEquals(test_section, "PR3_EX3_3", "error-setStaff ACN", E_SUCCESS, error, &state);
        if (!state.failed) {
            assertIntEquals(test_section, "PR3_EX3_3", "assigned staff-setStaff ACN", 2, data.campaignData.elems[2].staff->count, &state);
        }
    
        date_parse(&date, "02/02/2023");
        error = api_setStaffCampaigns(&data, "CRE", date);
        assertIntEquals(test_section, "PR3_EX3_3", "error-setStaff CRE", E_NO_AVAILABLE, error, &state);
         
        date_parse(&date, "12/01/2023");
        csv_init(&report);
        error = api_findStaffAvailable(&data, "ACN", date, &report);
        assertIntEquals(test_section, "PR3_EX3_3", "error", E_SUCCESS, error, &state);
        assertIntEquals(test_section, "PR3_EX3_3", "availibility(ACN)", 1, report.count, &state);
        csv_free(&report);
    }
    
    end_test(test_section, "PR3_EX3_3", !state.failed);
   
    // Release all data
    api_freeData(&data);
    
    return state.passed; 

}
