SET search_path TO ubd_20211;

SELECT * 
FROM BAND NATURAL JOIN MEMBER 
WHERE id_band = 1 OR id_band = 5 OR id_band = 11;

