SET search_path TO ubd_20211;

SELECT * FROM update_report_band('Free');
