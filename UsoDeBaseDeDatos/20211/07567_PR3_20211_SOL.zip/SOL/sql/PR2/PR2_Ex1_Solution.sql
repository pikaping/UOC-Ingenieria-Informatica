SET search_path TO ubd_20211;

CREATE OR REPLACE FUNCTION update_report_band(p_name VARCHAR(255))
RETURNS REPORT_BAND_TYPE AS $$
DECLARE 
	var_return_data REPORT_BAND_TYPE;
BEGIN
	IF((SELECT COUNT(*)
		FROM band AS b
		WHERE b.name = p_name) = 0)
	THEN
    	RAISE EXCEPTION 'ERROR: no band found for name "%" ', p_name;
	END IF;

	SELECT id_band 
	INTO var_return_data.t_id_band
	FROM band
	WHERE "name" = p_name;

	SELECT COUNT(DISTINCT me.instrument)
		INTO var_return_data.t_num_instruments
	FROM "member" AS me
	WHERE me.instrument <> 'Vocals'
	AND me.id_band = var_return_data.t_id_band;

	SELECT COUNT(DISTINCT me.id_musician)
		INTO var_return_data.t_num_members_alive
	FROM "member" AS me
	INNER JOIN musician AS mu 
	ON me.id_musician = mu.id_musician
	WHERE mu.death IS NULL
	AND me.id_band = var_return_data.t_id_band;

	SELECT a.title
		INTO var_return_data.t_longest_album_title
	FROM album AS a 
	LEFT JOIN song AS s 
	ON s.id_album = a.id_album 
	WHERE a.id_band = var_return_data.t_id_band
	GROUP BY a.id_album
	ORDER BY SUM(s.duration) DESC
	LIMIT 1;

	SELECT COUNT(s.id_song)
		INTO var_return_data.t_num_short_songs
	FROM song AS s
	INNER JOIN album AS a 
	ON s.id_album = a.id_album
	WHERE s.duration < '0:03:00'
	AND a.id_band = var_return_data.t_id_band;

	IF(NOT EXISTS(
		SELECT id_band
		FROM report_band
		WHERE id_band = var_return_data.t_id_band))
	THEN
    	INSERT INTO report_band
		VALUES (
        	var_return_data.t_id_band,
        	var_return_data.t_num_instruments,
        	var_return_data.t_num_members_alive,
        	var_return_data.t_longest_album_title,
        	var_return_data.t_num_short_songs);
	ELSE
    	UPDATE report_band
		SET num_instruments = var_return_data.t_num_instruments,
			num_members_alive = var_return_data.t_num_members_alive,	
			longest_album_title = var_return_data.t_longest_album_title,
			num_short_songs = var_return_data.t_num_short_songs
		WHERE id_band = var_return_data.t_id_band;
	END IF;
	RETURN var_return_data;
END;

$$LANGUAGE plpgsql;
