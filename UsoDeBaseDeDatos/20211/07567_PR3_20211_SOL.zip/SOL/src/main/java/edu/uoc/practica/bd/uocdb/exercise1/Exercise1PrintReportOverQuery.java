package edu.uoc.practica.bd.uocdb.exercise1;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;

import edu.uoc.practica.bd.util.Column;
import edu.uoc.practica.bd.util.DBAccessor;
import edu.uoc.practica.bd.util.Report;

public class Exercise1PrintReportOverQuery 
{
	public static void main(String[] args) 
	{
		Exercise1PrintReportOverQuery app = new Exercise1PrintReportOverQuery();
		app.run();
	}

	private void run() 
	{
		DBAccessor dbaccessor = new DBAccessor();
		dbaccessor.init();
		Connection conn = dbaccessor.getConnection();
	
		if (conn != null) 
		{
			Statement cstmt 	= null;
			ResultSet resultSet = null;
			
			try 
			{
				List<Column> columns = Arrays.asList (new Column("Id band",  		  7, "id_band"),
													  new Column("Num instruments",  15, "num_instruments"),
													  new Column("Num members alive",17, "num_members_alive"),
													  new Column("Big albums", 		 20, "big_albums"),
													  new Column("Num short songs",	 15, "num_short_songs"));
	
				Report report = new Report();
				report.setColumns(columns);
				List<Object> list = new ArrayList<Object>();
				
				// TODO Execute SQL sentence
				cstmt = conn.createStatement();
				resultSet = cstmt.executeQuery("SELECT * FROM report_band ORDER BY id_band");
				
				// TODO Loop over results and get the main values
				int id_band;
				int num_instruments;
				int num_members_alive;
				String big_albums;
				int num_short_songs;
				
				while (resultSet.next()) 
				{
					id_band				= resultSet.getInt(1);
					num_instruments		= resultSet.getInt(2);
					num_members_alive	= resultSet.getInt(3);
					big_albums			= resultSet.getString(4);
					num_short_songs		= resultSet.getInt(5);
					
					Exercise1Row row = new Exercise1Row (id_band, 
														 num_instruments,
														 num_members_alive,
														 big_albums,
														 num_short_songs);
					list.add(row);
				}
				
				// TODO End loop
				if (list.isEmpty())	System.out.println("List without data"); 
				else 				report.printReport(list);
			}
			catch (SQLException e)
			{
				System.err.println("ERROR: List not available");
				System.err.println(e.getMessage());
			}
			// TODO Close All resources
			finally
			{
				if (resultSet != null)
				{
					try 
					{
						resultSet.close();
					}
					catch (SQLException e) 
					{
						System.err.println("ERROR: Closing resultSet");
						System.err.println(e.getMessage());
					}
				}
				if (cstmt != null) 
				{
					try 
					{
						cstmt.close();
					} 
					catch (SQLException e) 
					{
						System.err.println("ERROR: Closing statement");
						System.err.println(e.getMessage());
					}
				}
				if (conn != null) 
				{
					try 
					{
						conn.close();
					}
					catch (SQLException e) 
					{
						System.err.println("ERROR: Closing connection");
						System.err.println(e.getMessage());
					}
				}
			}
		}
	}
}
