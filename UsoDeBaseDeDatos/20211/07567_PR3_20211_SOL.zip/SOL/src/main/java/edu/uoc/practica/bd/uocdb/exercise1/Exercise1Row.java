package edu.uoc.practica.bd.uocdb.exercise1;

public class Exercise1Row {

	private int id_band;
	private int num_instruments;
	private int num_members_alive;
	private String big_albums;
	private int num_short_songs;
	
	public Exercise1Row (int id_band,
						 int num_instruments,
						 int num_members_alive,
						 String big_albums,
						 int num_short_songs)
	{
		super();

		this.set_id_band(id_band);
		
		this.set_num_instruments(num_instruments);
		
		this.set_num_members_alive(num_members_alive);
			
		this.set_big_albums(big_albums);

		this.set_num_short_songs(num_short_songs);
	}
		
	
	public int get_id_band() { return this.id_band; }
	
	public int get_num_instruments() { return this.num_instruments; }
	
	public int get_num_members_alive() { return this.num_members_alive; }
	
	public String get_big_albums() { return this.big_albums; }
	
	public int get_num_short_songs() { return this.num_short_songs; }
	
	
	public void set_id_band(int id_band) { this.id_band = id_band; }
	
	public void set_num_instruments(int num_instruments) { this.num_instruments = num_instruments; }
	
	public void set_num_members_alive(int num_members_alive) { this.num_members_alive = num_members_alive;}
		
	public void set_big_albums(String big_albums) { this.big_albums = big_albums;}

	public void set_num_short_songs(int num_short_songs) { this.num_short_songs = num_short_songs; }

}