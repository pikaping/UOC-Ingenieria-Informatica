package edu.uoc.practica.bd.uocdb.exercise2;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.List;

import edu.uoc.practica.bd.util.DBAccessor;
import edu.uoc.practica.bd.util.FileUtilities;

public class Exercise2InsertAndUpdateDataFromFile 
{
	private FileUtilities fileUtilities;
	
	public Exercise2InsertAndUpdateDataFromFile()
	{
		super();
		fileUtilities = new FileUtilities();
	}
	
	public static void main(String[] args) 
	{
		Exercise2InsertAndUpdateDataFromFile app = new Exercise2InsertAndUpdateDataFromFile();
		app.run();
	}

	private void run() 
	{
		List<List<String>> fileContents = null;
		
		try 
		{
			fileContents = fileUtilities.readFileFromClasspath("exercise2.data");
		} 
		catch (FileNotFoundException e) 
		{
			System.err.println("ERROR: File not found");
			e.printStackTrace();
		} 
		catch (IOException e) 
		{
			System.err.println("ERROR: I/O error");
			e.printStackTrace();
		}
		
		if (fileContents == null)	return;
		
		DBAccessor dbaccessor = new DBAccessor();
		dbaccessor.init();
		Connection conn = dbaccessor.getConnection();

		// TODO Prepare everything before updating or inserting
		if (conn == null) return;
		
		// Prepared Statements declaration
		PreparedStatement psUpdateBand 	 = null;
		PreparedStatement psInsertBand   = null;
		PreparedStatement psSelectMember = null;
		PreparedStatement psInsertMember = null;
		
		ResultSet rs = null;
		
		try 
		{
			// SQL sentences
			String sqlUpdateBand   = "UPDATE band SET name = ?, year_formed = ?, year_dissolution = ?, style = ?, origin = ? WHERE id_band = ?";
			String sqlInsertBand   = "INSERT INTO band VALUES(?, ?, ?, ?, ?, ?)";
			String sqlSelectMember = "SELECT * FROM member WHERE id_musician = ? AND id_band = ? AND instrument = ?";
			String sqlInsertMember = "INSERT INTO member VALUES (?, ?, ?)";
			
			// Prepared Statement initialization
			psUpdateBand   = conn.prepareStatement(sqlUpdateBand);
			psInsertBand   = conn.prepareStatement(sqlInsertBand);
			psSelectMember = conn.prepareStatement(sqlSelectMember);
			psInsertMember = conn.prepareStatement(sqlInsertMember);
			
			// TODO Update or insert Song and Composer from every row in file
			for (List<String> row : fileContents) 
			{	
				// Updates song query
				psUpdateBand.clearParameters();
				setPSUpdateBand(psUpdateBand, row);
				
				if (psUpdateBand.executeUpdate() == 0)
				{
					System.out.println("Band does not exist. Inserting ...");
					
					psInsertBand.clearParameters();
					setPSInsertBand(psInsertBand, row);
					psInsertBand.executeUpdate();
				}
				else
				{
					System.out.println("Band updated correctly.");
				}
				
				psSelectMember.clearParameters();
				setPSSelectMember(psSelectMember, row);
				
				rs = psSelectMember.executeQuery();
				
				if(!rs.next()) 
				{
					System.out.println("Member information not present. Inserting ...");
					
					psInsertMember.clearParameters();
					setPSInsertMember(psInsertMember, row);
					psInsertMember.executeUpdate();
				}
				else
				{
					System.out.println("Member information already present.");
				}
				
				rs.close();
			}
					
			// TODO Validate transaction
			conn.commit();
		}
		// TODO Close resources and check exceptions
		catch (SQLException e1) 
		{
			System.err.println("ERROR: Executing SQL on BAND or MEMBER");
			System.err.println(e1.getMessage());
			
			try 
			{
				conn.rollback();
			}
			catch (SQLException e2)
			{
				System.out.println("Messagee:  " + e2.getMessage());
				System.out.println("SQLState:  " + e2.getSQLState());
				System.out.println("ErrorCode: " + e2.getErrorCode());
			}
		}
		finally
		{
			if (rs != null ) {
				try {
					rs.close();
				} 
				catch ( SQLException e) 
				{
					System.err.println("ERROR: Closing resultSet");
					System.err.println(e.getMessage());
				}
			}
			if (psUpdateBand != null)
			{
				try
				{
					psUpdateBand.close();
				}
				catch(SQLException e)
				{
					System.err.println("ERROR: Closing connection UPDATE band.");
					System.err.println(e.getMessage());
				}
			}
			
			if (psInsertBand != null)
			{
				try
				{
					psInsertBand.close();
				}
				catch(SQLException e)
				{
					System.err.println("ERROR: Closing connection INSERT band.");
					System.err.println(e.getMessage());
				}
			}
			
			if (psSelectMember != null)
			{
				try
				{
					psSelectMember.close();
				}
				catch(SQLException e)
				{
					System.err.println("ERROR: Closing connection SELECT member.");
					System.err.println(e.getMessage());
				}
			}
			
			if (psInsertMember != null)
			{
				try
				{
					psInsertMember.close();
				}
				catch(SQLException e)
				{
					System.err.println("ERROR: Closing connection INSERT member.");
					System.err.println(e.getMessage());
				}
			}
			
			if (conn != null) 
			{
				try 
				{
					conn.close();
				}
				catch (SQLException e) 
				{
					System.err.println("ERROR: Closing connection");
					System.err.println(e.getMessage());
				}
			}
		}
	}
	
	private void  setPSUpdateBand (PreparedStatement updateStatement, List<String> row) throws SQLException 
	{
		String[] rowArray = (String[]) row.toArray(new String[0]);
		setValueOrNull(updateStatement,  1, getValueIfNotNull(rowArray, 1));								// name
		setValueOrNull(updateStatement,  2, getIntegerFromStringOrNull(getValueIfNotNull(rowArray, 2)));	// year_formed  
		setValueOrNull(updateStatement,  3, getIntegerFromStringOrNull(getValueIfNotNull(rowArray, 3)));	// year_dissolution
		setValueOrNull(updateStatement,  4, getValueIfNotNull(rowArray, 4));								// style 
		setValueOrNull(updateStatement,  5, getValueIfNotNull(rowArray, 5));								// origin
		setValueOrNull(updateStatement,  6, getIntegerFromStringOrNull(getValueIfNotNull(rowArray, 0)));	// id_band
	}
	
	
	private void  setPSInsertBand (PreparedStatement insertStatement, List<String> row) throws SQLException 
	{
		String[] rowArray = (String[]) row.toArray(new String[0]);

		setValueOrNull(insertStatement,  1, getIntegerFromStringOrNull(getValueIfNotNull(rowArray, 0))); 	// id_band
		setValueOrNull(insertStatement,  2, getValueIfNotNull(rowArray, 1));								// name
		setValueOrNull(insertStatement,  3, getIntegerFromStringOrNull(getValueIfNotNull(rowArray, 2)));	// year_formed 
		setValueOrNull(insertStatement,  4, getIntegerFromStringOrNull(getValueIfNotNull(rowArray, 3)));	// year_dissolution
		setValueOrNull(insertStatement,  5, getValueIfNotNull(rowArray, 4));								// style 
		setValueOrNull(insertStatement,  6, getValueIfNotNull(rowArray, 5));								// origin
	}
	
	private void  setPSSelectMember (PreparedStatement selectStatement, List<String> row) throws SQLException 
	{
		String[] rowArray = (String[]) row.toArray(new String[0]);
			
		setValueOrNull(selectStatement, 1, getIntegerFromStringOrNull(getValueIfNotNull(rowArray, 6))); // id_musician  
		setValueOrNull(selectStatement, 2, getIntegerFromStringOrNull(getValueIfNotNull(rowArray, 0))); // id_band
		setValueOrNull(selectStatement, 3, getValueIfNotNull(rowArray, 7)); 							// id_instrument
	}
	
	private void  setPSInsertMember (PreparedStatement insertStatement, List<String> row) throws SQLException 
	{
		String[] rowArray = (String[]) row.toArray(new String[0]);
			
		setValueOrNull(insertStatement, 1, getIntegerFromStringOrNull(getValueIfNotNull(rowArray, 6))); // id_musician  
		setValueOrNull(insertStatement, 2, getIntegerFromStringOrNull(getValueIfNotNull(rowArray, 0))); // id_band
		setValueOrNull(insertStatement, 3, getValueIfNotNull(rowArray, 7));								// id_instrument
	}
	
	private Integer getIntegerFromStringOrNull(String integer) 
	{
		return (integer != null) ? Integer.valueOf(integer) : null;
	}
	
	private String getValueIfNotNull(String[] rowArray, int index) 
	{
		return (index < rowArray.length && rowArray[index].length() > 0) ? rowArray[index] : null;
	}

	private void setValueOrNull(PreparedStatement preparedStatement, int parameterIndex, Integer value)	throws SQLException 
	{
		if (value == null)	preparedStatement.setNull(parameterIndex, Types.INTEGER);
		else 				preparedStatement.setInt(parameterIndex, value);
	}

	private void setValueOrNull(PreparedStatement preparedStatement, int parameterIndex, String value) throws SQLException 
	{
		if (value == null || value.length() == 0) 	preparedStatement.setNull(parameterIndex, Types.VARCHAR);
		else 										preparedStatement.setString(parameterIndex, value);
	}
}
