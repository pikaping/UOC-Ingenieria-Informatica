SET search_path TO ubd_20222;

SELECT * FROM update_report_dog('Rocky');
SELECT * FROM update_report_dog('Max');

