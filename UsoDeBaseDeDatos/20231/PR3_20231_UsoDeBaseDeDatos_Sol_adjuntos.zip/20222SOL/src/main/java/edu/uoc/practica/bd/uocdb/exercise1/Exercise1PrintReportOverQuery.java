package edu.uoc.practica.bd.uocdb.exercise1;

import edu.uoc.practica.bd.util.Column;
import edu.uoc.practica.bd.util.DBAccessor;
import edu.uoc.practica.bd.util.Report;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Exercise1PrintReportOverQuery {

  public static void main(String[] args) {
    Exercise1PrintReportOverQuery app = new Exercise1PrintReportOverQuery();
    app.run();
  }

  private void run() {
    DBAccessor dbaccessor = new DBAccessor();
    dbaccessor.init();
    Connection conn = dbaccessor.getConnection();

    if (conn != null) {
      Statement cstmt = null;
      ResultSet resultSet = null;

      try {

        List<Column> columns = Arrays.asList(new Column("Id dog", 7, "id_dog"),
            new Column("Name dog", 8, "name_dog"),
            new Column("Num visits", 10, "num_visits"),
            new Column("Num dif. vac.", 13, "num_dif_vaccines"),
            new Column("Date last vac.", 14, "date_last_vaccine"),
            new Column("Num drugs", 9, "num_drugs"),
            new Column("Num tests", 9, "num_tests"));

        Report report = new Report();
        report.setColumns(columns);
        List<Object> list = new ArrayList<Object>();

        // TODO Execute SQL sentence
        cstmt = conn.createStatement();
        resultSet = cstmt.executeQuery("SELECT * FROM report_dog ORDER BY num_visits DESC, name_dog");

        // TODO Loop over results and get the main values
        int id_dog;
        String name_dog;
        int num_visits;
        int num_dif_vaccines;
        String date_last_vaccine;
        int num_drugs;
        int num_tests;

        while (resultSet.next()) {
          id_dog = resultSet.getInt(1);
          name_dog = resultSet.getString(2);
          num_visits = resultSet.getInt(6);
          num_dif_vaccines = resultSet.getInt(7);
          date_last_vaccine = resultSet.getString(8);
          num_drugs = resultSet.getInt(9);
          num_tests = resultSet.getInt(10);

          Exercise1Row row = new Exercise1Row(
              id_dog,
              name_dog,
              num_visits,
              num_dif_vaccines,
              date_last_vaccine,
              num_drugs,
              num_tests);
          list.add(row);
        }

        // TODO End loop
        if (list.isEmpty()) {
          System.out.println("List without data");
        } else {
          report.printReport(list);
        }
      } catch (SQLException e) {
        System.err.println("ERROR: List not available");
        System.err.println(e.getMessage());
      }
      // TODO Close All resources
      finally {
        if (resultSet != null) {
          try {
            resultSet.close();
          } catch (SQLException e) {
            System.err.println("ERROR: Closing resultSet");
            System.err.println(e.getMessage());
          }
        }
        if (cstmt != null) {
          try {
            cstmt.close();
          } catch (SQLException e) {
            System.err.println("ERROR: Closing statement");
            System.err.println(e.getMessage());
          }
        }
        if (conn != null) {
          try {
            conn.close();
          } catch (SQLException e) {
            System.err.println("ERROR: Closing connection");
            System.err.println(e.getMessage());
          }
        }
      }
    }
  }
}
